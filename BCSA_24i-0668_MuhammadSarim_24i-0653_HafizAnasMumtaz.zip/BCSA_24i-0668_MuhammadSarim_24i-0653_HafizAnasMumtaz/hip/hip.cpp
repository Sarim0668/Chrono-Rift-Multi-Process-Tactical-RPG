/* It Handles player input, terminal UI, and sends actions to arbiter */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <termios.h>
#include <ctype.h>
#include <errno.h>
#include <SFML/Graphics.hpp>
#include "GameState.h"
#include "SharedMemoryManager.h"
#include <sys/shm.h>


// Sfml font

sf::Font g_font;
bool g_fontLoaded = false;

//Global Variables
static SharedMemoryManager* g_shm = nullptr;
static GameState* g_state = nullptr;
static int g_running = 1;
static pthread_mutex_t g_runMutex = PTHREAD_MUTEX_INITIALIZER;

static int g_stunReceived = 0;
static pthread_mutex_t g_stunMutex = PTHREAD_MUTEX_INITIALIZER;

/* Safe accessors replace volatile reads/writes */
static int getRunning()  { pthread_mutex_lock(&g_runMutex);  int v = g_running;      pthread_mutex_unlock(&g_runMutex);  return v; }
static void setRunning(int v) { pthread_mutex_lock(&g_runMutex);  g_running = v;     pthread_mutex_unlock(&g_runMutex); }
static int getStunReceived()  { pthread_mutex_lock(&g_stunMutex); int v = g_stunReceived; pthread_mutex_unlock(&g_stunMutex); return v; }
static void setStunReceived(int v) { pthread_mutex_lock(&g_stunMutex); g_stunReceived = v; pthread_mutex_unlock(&g_stunMutex); }
static bool g_isHip2 = false;

/* 0 for HIP1 1 for HIP2. Used to match playerOwner[] in shared memory. */
static int g_hipOwnerIndex = 0;

static pthread_t g_playerThreads[MAX_PLAYERS];
static int g_playerIds[MAX_PLAYERS];
static pthread_t g_watcherThread;
static pthread_t g_sfmlThread;


/* SFML input variables for menu, target selection, Y/N prompts, and weapon picker */
static int g_sfmlChoice = -1;
static int g_sfmlState = 0; // 0=idle, 1=waiting action, 2=waiting target, 5=waiting yn, 6=waiting enter
static int g_selectedButton = 1;
static int g_currentNumEnemies = 0;
static int g_selectedEnemy = 0;
static int g_sfmlTarget = -1;
static char g_dropWeaponName[32];
static int g_ynSelected = 0;
static char g_sfmlYN = 0;


//Weapon picker
static int g_weaponPickerSelected = 0;
static int g_weaponPickerCount = 0;
static int g_weaponPickerResult = -1;
struct WeaponPickerEntry { char name[32]; int damage; int slotSize; bool isArtifact; int invSlot; };
static WeaponPickerEntry g_weaponPickerList[INVENTORY_SIZE];


static pthread_mutex_t g_sfmlMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t g_inputMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_inputCond  = PTHREAD_COND_INITIALIZER;


// Turn coordination
static pthread_mutex_t g_turnMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_turnCond = PTHREAD_COND_INITIALIZER;




// SFML DRAW FUNCTIONS
void drawText(sf::RenderWindow& w, const std::string& s, float x, float y, unsigned sz, sf::Color c) {
    if (!g_fontLoaded) return;
    sf::Text t;
    t.setFont(g_font);
    t.setString(s);
    t.setCharacterSize(sz);
    t.setFillColor(c);
    t.setPosition(x, y);
    w.draw(t);
}

//Drawing bar
void drawBar(sf::RenderWindow& w, float x, float y, float width, float height, float ratio,
             sf::Color bg, sf::Color fg) {
    sf::RectangleShape bgRect(sf::Vector2f(width, height));
    bgRect.setPosition(x, y);
    bgRect.setFillColor(bg);
    w.draw(bgRect);
    if (ratio > 0) {
        sf::RectangleShape fgRect(sf::Vector2f(width * ratio, height));
        fgRect.setPosition(x, y);
        fgRect.setFillColor(fg);
        w.draw(fgRect);
    }
}


//SFML DISPLAYSS
struct SfmlWeaponEntry {
    char name[32];
    int  damage;
    int  slotSize;
    bool isArtifact;
};
struct SfmlMenuSnapshot {
    // Active player info
    char playerName[32];
    int  playerHp, playerMaxHp;
    int  playerStamina, playerMaxStamina;
    int  playerDamage;
    bool playerUltimate;      // has Solar Core AND Lunar Blade
    // Enemies
    int  numEnemies;
    char enemyName[MAX_ENEMIES][32];
    int  enemyHp[MAX_ENEMIES];
    int  enemyMaxHp[MAX_ENEMIES];
    bool enemyArmed[MAX_ENEMIES];
    int  activePlayerId;
    int  inventoryUsedSlots;
    SfmlWeaponEntry primaryInventory[20]; // up to 20 entries (unique weapons only)
    int  primaryCount;
    SfmlWeaponEntry longTermStorage[10];
    int  longTermCount;
};
static SfmlMenuSnapshot g_menuSnap;
static pthread_mutex_t  g_menuSnapMutex = PTHREAD_MUTEX_INITIALIZER;


// SFML INPUT WINDOW THREAD
void* sfmlInputThread(void*) {
    sf::RenderWindow window(sf::VideoMode(780, 700), "Chrono Rift - Player Input");
    window.setFramerateLimit(30);
    
    const char* fonts[] = {
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-R.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        nullptr
    };
    for (int i = 0; fonts[i]; i++) {
        if (g_font.loadFromFile(fonts[i])) {
            g_fontLoaded = true;
            break;
        }
    }
    
    while (getRunning() && window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                // Signal player thread: treat as quit
                pthread_mutex_lock(&g_sfmlMutex);
                g_sfmlChoice = 8;
                g_sfmlState = 0;
                pthread_mutex_unlock(&g_sfmlMutex);
                pthread_mutex_lock(&g_inputMutex);
                pthread_cond_broadcast(&g_inputCond);
                pthread_mutex_unlock(&g_inputMutex);
            }
            else if (event.type == sf::Event::KeyPressed) {
                pthread_mutex_lock(&g_sfmlMutex);
                int curState = g_sfmlState;
                bool signalInput = false;

                // state 6 or 7 inventory/enter to continue
                if (curState == 6 || curState == 7) {
                    if (event.key.code == sf::Keyboard::Enter ||
                        event.key.code == sf::Keyboard::Space) {
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                }
                // state 1 action menu
                else if (curState == 1) {
                    if (event.key.code == sf::Keyboard::Up && g_selectedButton > 1) {
                        g_selectedButton--;
                    }
                    else if (event.key.code == sf::Keyboard::Down && g_selectedButton < 8) {
                        g_selectedButton++;
                    }
                    else if (event.key.code == sf::Keyboard::Enter) {
                        g_sfmlChoice = g_selectedButton;
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                }
                // state 2 enemy target
                else if (curState == 2) {
                    if (event.key.code == sf::Keyboard::Up && g_selectedEnemy > 0) {
                        g_selectedEnemy--;
                    }
                    else if (event.key.code == sf::Keyboard::Down && g_selectedEnemy < g_currentNumEnemies - 1) {
                        g_selectedEnemy++;
                    }
                    else if (event.key.code == sf::Keyboard::Enter) {
                        g_sfmlTarget = g_selectedEnemy;
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                    else if (event.key.code == sf::Keyboard::Escape) {
                        g_sfmlTarget = -2;
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                }
                // state 3 weapon picker
                else if (curState == 3) {
                    if (event.key.code == sf::Keyboard::Up && g_weaponPickerSelected > 0) {
                        g_weaponPickerSelected--;
                    }
                    else if (event.key.code == sf::Keyboard::Down && g_weaponPickerSelected < g_weaponPickerCount - 1) {
                        g_weaponPickerSelected++;
                    }
                    else if (event.key.code == sf::Keyboard::Enter) {
                        g_weaponPickerResult = g_weaponPickerSelected;
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                    else if (event.key.code == sf::Keyboard::Escape) {
                        g_weaponPickerResult = -2;
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                }
                // state 5 Y/N weapon drop
                else if (curState == 5) {
                    if (event.key.code == sf::Keyboard::Left) {
                        g_ynSelected = 0;
                    }
                    else if (event.key.code == sf::Keyboard::Right) {
                        g_ynSelected = 1;
                    }
                    else if (event.key.code == sf::Keyboard::Enter) {
                        g_sfmlYN = (g_ynSelected == 0) ? 'y' : 'n';
                        g_sfmlState = 0;
                        signalInput = true;
                    }
                }

                pthread_mutex_unlock(&g_sfmlMutex);

                // Wake up any waiting player thread done OUTSIDE g_sfmlMutex to avoid inversion
                if (signalInput) {
                    pthread_mutex_lock(&g_inputMutex);
                    pthread_cond_broadcast(&g_inputCond);
                    pthread_mutex_unlock(&g_inputMutex);
                }
            }
        }
        
        window.clear(sf::Color(20, 20, 40));
        
        pthread_mutex_lock(&g_menuSnapMutex);
        SfmlMenuSnapshot snap = g_menuSnap;
        pthread_mutex_unlock(&g_menuSnapMutex);
        
        // Briefly copy sfml state 
        pthread_mutex_lock(&g_sfmlMutex);
        int curState = g_sfmlState;
        int curSel = g_selectedButton;
        int curEnemy = g_selectedEnemy;
        int curNumEnemies = g_currentNumEnemies;
        int curYN = g_ynSelected;
        
        // weapon picker snapshot
        int curWpSel = g_weaponPickerSelected;
        int curWpCount = g_weaponPickerCount;
        WeaponPickerEntry curWpList[INVENTORY_SIZE];
        memcpy(curWpList, g_weaponPickerList, sizeof(curWpList));
        char dropName[32];
        strncpy(dropName, g_dropWeaponName, sizeof(dropName)-1);
        dropName[sizeof(dropName)-1] = '\0';
        pthread_mutex_unlock(&g_sfmlMutex);
        
        
        // HEADER
        {
            sf::RectangleShape hdr(sf::Vector2f(780, 36));
            hdr.setPosition(0, 0);
            hdr.setFillColor(sf::Color(0, 0, 0, 220));
            window.draw(hdr);
            drawText(window, "CHRONO RIFT - INPUT", 230, 7, 20, sf::Color(220, 180, 60));
        }
        
        float y = 48;
        
        // PLAYER STATS PANEL
        {
            sf::RectangleShape panel(sf::Vector2f(760, 80));
            panel.setPosition(10, y);
            panel.setFillColor(sf::Color(10, 20, 50, 220));
            panel.setOutlineColor(sf::Color(80, 120, 200));
            panel.setOutlineThickness(2);
            window.draw(panel);
            
            char info[128];
            snprintf(info, sizeof(info), "PLAYER: %s   HP: %d/%d   STAMINA: %d/%d   DMG: %d",
                     snap.playerName, snap.playerHp, snap.playerMaxHp,
                     snap.playerStamina, snap.playerMaxStamina, snap.playerDamage);
            drawText(window, info, 18, y + 6, 13, sf::Color::White);
            
            float hpRatio = snap.playerMaxHp > 0 ? (float)snap.playerHp / snap.playerMaxHp : 0;
            sf::Color hpColor = hpRatio > 0.5f ? sf::Color(50, 200, 50) :
                                hpRatio > 0.25f ? sf::Color(220, 180, 0) : sf::Color(220, 50, 50);
            drawText(window, "HP:", 18, y + 28, 11, sf::Color(180, 180, 180));
            drawBar(window, 48, y + 30, 340, 14, hpRatio, sf::Color(60, 20, 20), hpColor);
            
            float stRatio = snap.playerMaxStamina > 0 ? (float)snap.playerStamina / snap.playerMaxStamina : 0;
            drawText(window, "SP:", 410, y + 28, 11, sf::Color(180, 180, 180));
            drawBar(window, 440, y + 30, 300, 14, stRatio, sf::Color(20, 20, 60), sf::Color(0, 150, 255));
            
            if (snap.playerUltimate) {
                drawText(window, "★ ULTIMATE READY! (Solar Core + Lunar Blade) ★",
                         18, y + 56, 13, sf::Color(255, 100, 0));
            }
        }
        y += 92;
        
        // ENEMIES PANEL
        if (snap.numEnemies > 0) {
            sf::RectangleShape ep(sf::Vector2f(760, 20 + snap.numEnemies * 26));
            ep.setPosition(10, y);
            ep.setFillColor(sf::Color(40, 10, 10, 200));
            ep.setOutlineColor(sf::Color(160, 80, 80));
            ep.setOutlineThickness(2);
            window.draw(ep);
            drawText(window, "ENEMIES:", 18, y + 2, 13, sf::Color(255, 120, 120));
            for (int i = 0; i < snap.numEnemies; i++) {
                char buf[80];
                float hpR = snap.enemyMaxHp[i] > 0 ? (float)snap.enemyHp[i] / snap.enemyMaxHp[i] : 0;
                snprintf(buf, sizeof(buf), "%d. %s  HP:%d/%d%s",
                         i + 1, snap.enemyName[i], snap.enemyHp[i], snap.enemyMaxHp[i],
                         snap.enemyArmed[i] ? " [ARMED]" : "");
                sf::Color ec = (curState == 2 && curEnemy == i) ?
                               sf::Color::Yellow : sf::Color(220, 200, 200);
                drawText(window, buf, 18, y + 20 + i * 26, 12, ec);
                drawBar(window, 420, y + 22 + i * 26, 280, 10,
                        hpR, sf::Color(40, 10, 10), sf::Color(180, 60, 60));
            }
            y += 22 + snap.numEnemies * 26 + 8;
        }
        
        // SEPARATOR
        {
            sf::RectangleShape sep(sf::Vector2f(760, 2));
            sep.setPosition(10, y);
            sep.setFillColor(sf::Color(80, 80, 120));
            window.draw(sep);
            y += 10;
        }
        
        //  STATE SPECIFIC PANELS
        if (curState == 7) {
            // INVENTORY DISPLAY
            sf::RectangleShape invBg(sf::Vector2f(760, 260));
            invBg.setPosition(10, y);
            invBg.setFillColor(sf::Color(10, 15, 35, 230));
            invBg.setOutlineColor(sf::Color(100, 80, 180));
            invBg.setOutlineThickness(2);
            window.draw(invBg);

            drawText(window, "INVENTORY", 18, y + 4, 16, sf::Color(200, 160, 255));
            char slotInfo[48];
            snprintf(slotInfo, sizeof(slotInfo), "Slots used: %d / 20", snap.inventoryUsedSlots);
            drawText(window, slotInfo, 200, y + 6, 12, sf::Color(180, 180, 180));

            float iy = y + 28;
            drawText(window, "PRIMARY INVENTORY:", 18, iy, 12, sf::Color(100, 220, 255));
            iy += 16;
            if (snap.primaryCount == 0) {
                drawText(window, "  (empty)", 18, iy, 11, sf::Color(120, 120, 120));
                iy += 16;
            }
            for (int i = 0; i < snap.primaryCount; i++) {
                char wbuf[80];
                snprintf(wbuf, sizeof(wbuf), "  %d. %-16s  DMG:%-3d  Size:%-2d%s",
                         i + 1,
                         snap.primaryInventory[i].name,
                         snap.primaryInventory[i].damage,
                         snap.primaryInventory[i].slotSize,
                         snap.primaryInventory[i].isArtifact ? " [ARTIFACT]" : "");
                sf::Color wc = snap.primaryInventory[i].isArtifact ?
                               sf::Color(255, 200, 50) : sf::Color(220, 220, 220);
                drawText(window, wbuf, 18, iy, 11, wc);
                iy += 15;
            }
            iy += 6;
            drawText(window, "LONG TERM STORAGE:", 18, iy, 12, sf::Color(100, 220, 255));
            iy += 16;
            if (snap.longTermCount == 0) {
                drawText(window, "  (empty)", 18, iy, 11, sf::Color(120, 120, 120));
                iy += 16;
            }
            for (int i = 0; i < snap.longTermCount; i++) {
                char wbuf[64];
                snprintf(wbuf, sizeof(wbuf), "  %d. %-16s  DMG:%d",
                         i, snap.longTermStorage[i].name, snap.longTermStorage[i].damage);
                drawText(window, wbuf, 18, iy, 11, sf::Color(200, 180, 140));
                iy += 15;
            }
            drawText(window, "ENTER or SPACE to continue", 220, y + 238, 12, sf::Color(150, 255, 150));
        }
        else if (curState == 6) {
            // Enter to continue
            sf::RectangleShape bg(sf::Vector2f(760, 60));
            bg.setPosition(10, y);
            bg.setFillColor(sf::Color(10, 15, 35, 230));
            bg.setOutlineColor(sf::Color(100, 80, 180));
            bg.setOutlineThickness(2);
            window.draw(bg);
            drawText(window, "Press ENTER or SPACE to continue", 160, y + 18, 14, sf::Color::White);
        }
        else if (curState == 1) {
            // Full action menu
            drawText(window, "SELECT ACTION  (UP/DOWN + ENTER)",
                     18, y, 14, sf::Color(200, 200, 255));
            y += 20;
            
            const char* actions[] = {
                "1. Attack (Strike)",
                "2. Attack (Exhaust)",
                "3. Use Weapon",
                "4. Swap In",
                "5. Heal",
                "6. Skip",
                "7. Inventory",
                "8. Quit"
            };
            const char* desc[] = {
                "Deal damage to selected enemy",
                "Drain enemy stamina",
                "Use a weapon from inventory",
                "Retrieve weapon from storage",
                "Restore 10% HP",
                "Skip turn (keeps 50% stamina)",
                "View inventory",
                "Exit game"
            };
            
            for (int i = 0; i < 8; i++) {
                bool sel = (curSel == i + 1);
                sf::RectangleShape row(sf::Vector2f(670, 26));
                row.setPosition(45, y + i * 30);
                row.setFillColor(sel ? sf::Color(60, 60, 140, 200) : sf::Color(20, 20, 50, 160));
                if (sel) { row.setOutlineColor(sf::Color::Yellow); row.setOutlineThickness(2); }
                window.draw(row);
                
                sf::Color ac = sel ? sf::Color::Yellow : sf::Color(200, 200, 200);
                drawText(window, actions[i], 58, y + i * 30 + 4, 15, ac);
                drawText(window, desc[i],   275, y + i * 30 + 7, 12, sf::Color(160, 160, 160));
            }
        }
        else if (curState == 2) {
            // Enemy target selection
            drawText(window, "SELECT ENEMY TARGET  (UP/DOWN + ENTER  |  ESC = Back)", 18, y, 14, sf::Color(200, 200, 255));
            y += 22;
            for (int i = 0; i < curNumEnemies; i++) {
                bool sel = (curEnemy == i);
                sf::RectangleShape row(sf::Vector2f(670, 30));
                row.setPosition(45, y + i * 34);
                row.setFillColor(sel ? sf::Color(120, 30, 30, 200) : sf::Color(40, 10, 10, 160));
                if (sel) { row.setOutlineColor(sf::Color::Yellow); row.setOutlineThickness(2); }
                window.draw(row);
                
                char buf[64];
                snprintf(buf, sizeof(buf), "%d.  %s   HP: %d/%d%s",
                         i + 1, snap.enemyName[i], snap.enemyHp[i], snap.enemyMaxHp[i],
                         snap.enemyArmed[i] ? " [ARMED]" : "");
                sf::Color ec = sel ? sf::Color::Yellow : sf::Color(220, 200, 200);
                drawText(window, buf, 58, y + i * 34 + 6, 14, ec);
            }
        }
        else if (curState == 3) {
            // Weapon picker
            drawText(window, "SELECT WEAPON TO USE  (UP/DOWN + ENTER  |  ESC = Back)",
                     18, y, 14, sf::Color(200, 200, 255));
            y += 22;
            if (curWpCount == 0) {
                sf::RectangleShape row(sf::Vector2f(670, 30));
                row.setPosition(45, y);
                row.setFillColor(sf::Color(30, 30, 30, 180));
                window.draw(row);
                drawText(window, "  (No weapons in inventory)", 58, y + 7, 14, sf::Color(180, 120, 120));
            }
            for (int i = 0; i < curWpCount; i++) {
                bool sel = (curWpSel == i);
                sf::RectangleShape row(sf::Vector2f(670, 32));
                row.setPosition(45, y + i * 36);
                row.setFillColor(sel ? sf::Color(40, 80, 140, 220) : sf::Color(15, 25, 60, 180));
                if (sel) { row.setOutlineColor(sf::Color::Yellow); row.setOutlineThickness(2); }
                window.draw(row);
                char buf2[96];
                snprintf(buf2, sizeof(buf2), "%d.  %-16s  DMG: %-3d  Size: %d%s",
                         i + 1,
                         curWpList[i].name,
                         curWpList[i].damage,
                         curWpList[i].slotSize,
                         curWpList[i].isArtifact ? "  [ARTIFACT]" : "");
                sf::Color wc = curWpList[i].isArtifact ?
                               (sel ? sf::Color(255, 230, 80) : sf::Color(255, 200, 50)) :
                               (sel ? sf::Color::Yellow : sf::Color(220, 220, 220));
                drawText(window, buf2, 58, y + i * 36 + 8, 14, wc);
            }
        }
        else if (curState == 5) {
            // Weapon drop Y/N
            drawText(window, "!! WEAPON DROP !!", 200, y, 20, sf::Color(255, 200, 0));
            y += 36;
            char buf[100];
            snprintf(buf, sizeof(buf), "Weapon: %s", dropName);
            drawText(window, buf, 18, y, 15, sf::Color::White);
            y += 36;
            drawText(window, "Pick up this weapon?", 18, y, 14, sf::Color(200, 200, 200));
            y += 42;
            
            sf::RectangleShape yesRect(sf::Vector2f(160, 44));
            yesRect.setPosition(80, y);
            yesRect.setFillColor(curYN == 0 ? sf::Color(0, 140, 0) : sf::Color(0, 60, 0));
            yesRect.setOutlineColor(curYN == 0 ? sf::Color::Yellow : sf::Color(80, 80, 80));
            yesRect.setOutlineThickness(2);
            window.draw(yesRect);
            drawText(window, "YES", 138, y + 12, 16, sf::Color::White);
            
            sf::RectangleShape noRect(sf::Vector2f(160, 44));
            noRect.setPosition(480, y);
            noRect.setFillColor(curYN == 1 ? sf::Color(140, 0, 0) : sf::Color(60, 0, 0));
            noRect.setOutlineColor(curYN == 1 ? sf::Color::Yellow : sf::Color(80, 80, 80));
            noRect.setOutlineThickness(2);
            window.draw(noRect);
            drawText(window, "NO", 542, y + 12, 16, sf::Color::White);
            
            drawText(window, "LEFT/RIGHT + ENTER", 230, y + 56, 12, sf::Color(150, 150, 150));
        }
        else {
            // Idle/waiting screen
            sf::RectangleShape idleBg(sf::Vector2f(760, 44));
            idleBg.setPosition(10, y);
            idleBg.setFillColor(sf::Color(0, 0, 0, 180));
            idleBg.setOutlineColor(sf::Color(80, 160, 80));
            idleBg.setOutlineThickness(2);
            window.draw(idleBg);
            drawText(window, "Waiting for your turn...", 200, y + 12, 15, sf::Color(100, 255, 100));
        }
        
        window.display();
        sf::sleep(sf::milliseconds(16)); 

        // Close HIP input window automatically when game ends
        if (!g_state->gameRunning && window.isOpen()) {
            sf::sleep(sf::seconds(3));
            window.close();
        }
    }
    return nullptr;
}


// Signal Handler
static void signalHandler(int sig) {
    if (sig == SIGTERM) {
        setRunning(0);
    } else if (sig == SIGUSR1) {
        setStunReceived(1);
    }
}


// UI Display Functions

static void clearScreen() {
    printf("\033[2J\033[1;1H");
    fflush(stdout);
}

static void showHeader() {
    printf("\n");
    printf("╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║                        CHRONO RIFT - HIP                        ║\n");
    printf("║                      SFML Input Interface                       ║\n");
    printf("╚══════════════════════════════════════════════════════════════════╝\n");
    printf("\n");
}


// SFML Input readers
static int readNumberFromBufferSFML() {
    // Set state with a brief lock then wait on the separate input cond
    pthread_mutex_lock(&g_sfmlMutex);
    g_sfmlState = 1;
    g_selectedButton = 1;
    g_sfmlChoice = -1;
    pthread_mutex_unlock(&g_sfmlMutex);
    
    // Sleep on g_inputCond  NOT g_sfmlMutex so the SFML render loop is never blocked
    pthread_mutex_lock(&g_inputMutex);
    while (getRunning() && g_state->gameRunning) {
        pthread_mutex_lock(&g_sfmlMutex);
        int c = g_sfmlChoice;
        pthread_mutex_unlock(&g_sfmlMutex);
        if (c != -1) break;
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 2; 
        pthread_cond_timedwait(&g_inputCond, &g_inputMutex, &ts);
    }
    pthread_mutex_unlock(&g_inputMutex);
    
    pthread_mutex_lock(&g_sfmlMutex);
    int result = g_sfmlChoice;
    g_sfmlState = 0;
    pthread_mutex_unlock(&g_sfmlMutex);
    return (result == -1) ? 8 : result; 
}

static int readTargetFromBufferSFML(int numEnemies) {
    pthread_mutex_lock(&g_sfmlMutex);
    g_sfmlState = 2;
    g_currentNumEnemies = numEnemies;
    g_selectedEnemy = 0;
    g_sfmlTarget = -1;
    pthread_mutex_unlock(&g_sfmlMutex);
    
    pthread_mutex_lock(&g_inputMutex);
    while (getRunning() && g_state->gameRunning) {
        pthread_mutex_lock(&g_sfmlMutex);
        int t = g_sfmlTarget;
        pthread_mutex_unlock(&g_sfmlMutex);
        if (t != -1) break;
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 2;
        pthread_cond_timedwait(&g_inputCond, &g_inputMutex, &ts);
    }
    pthread_mutex_unlock(&g_inputMutex);
    
    pthread_mutex_lock(&g_sfmlMutex);
    int result = g_sfmlTarget;
    g_sfmlState = 0;
    pthread_mutex_unlock(&g_sfmlMutex);
    if (result == -2) return 0;
    return result + 1;
}

static char readYNFromBufferSFML(const char* weaponName) {
    pthread_mutex_lock(&g_sfmlMutex);
    g_sfmlState = 5;
    strncpy(g_dropWeaponName, weaponName, sizeof(g_dropWeaponName)-1);
    g_dropWeaponName[sizeof(g_dropWeaponName)-1] = '\0';
    g_ynSelected = 0;
    g_sfmlYN = 0;
    pthread_mutex_unlock(&g_sfmlMutex);
    
    pthread_mutex_lock(&g_inputMutex);
    while (getRunning() && g_state->gameRunning) {
        pthread_mutex_lock(&g_sfmlMutex);
        char yn = g_sfmlYN;
        pthread_mutex_unlock(&g_sfmlMutex);
        if (yn != 0) break;
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 2;
        pthread_cond_timedwait(&g_inputCond, &g_inputMutex, &ts);
    }
    pthread_mutex_unlock(&g_inputMutex);
    
    pthread_mutex_lock(&g_sfmlMutex);
    char result = (g_sfmlYN != 0) ? g_sfmlYN : 'n'; // default n if game ended
    g_sfmlState = 0;
    pthread_mutex_unlock(&g_sfmlMutex);
    return result;
}


/* Returns the inventory slot index of the chosen weapon, or -1 if cancelled or no weapons */
static int readWeaponFromBufferSFML(int playerId) {
    pthread_mutex_lock(&g_sfmlMutex);
    g_weaponPickerCount = 0;
    g_weaponPickerSelected = 0;
    g_weaponPickerResult = -1;
    pthread_mutex_unlock(&g_sfmlMutex);

    g_shm->lockState();
    Entity& p = g_state->players[playerId];
    WeaponPickerEntry tmpList[INVENTORY_SIZE];
    int tmpCount = 0;
    for (int s = 0; s < INVENTORY_SIZE && tmpCount < INVENTORY_SIZE; s++) {
        if (p.inventory[s].slotSize == 0) continue;
        bool isStart = (s == 0) ||
                       (p.inventory[s-1].slotSize == 0) ||
                       (strcmp(p.inventory[s-1].name, p.inventory[s].name) != 0);
        if (!isStart) continue;
        strncpy(tmpList[tmpCount].name, p.inventory[s].name, 31);
        tmpList[tmpCount].name[31] = '\0';
        tmpList[tmpCount].damage = p.inventory[s].damage;
        tmpList[tmpCount].slotSize = p.inventory[s].slotSize;
        tmpList[tmpCount].isArtifact = (p.inventory[s].isArtifact != 0);
        tmpList[tmpCount].invSlot = s;
        tmpCount++;
    }
    g_shm->unlockState();

    if (tmpCount == 0) return -1;

    pthread_mutex_lock(&g_sfmlMutex);
    g_weaponPickerCount = tmpCount;
    memcpy(g_weaponPickerList, tmpList, sizeof(WeaponPickerEntry) * tmpCount);
    g_sfmlState = 3;
    pthread_mutex_unlock(&g_sfmlMutex);

    pthread_mutex_lock(&g_inputMutex);
    while (getRunning() && g_state->gameRunning) {
        pthread_mutex_lock(&g_sfmlMutex);
        int r = g_weaponPickerResult;
        pthread_mutex_unlock(&g_sfmlMutex);
        if (r != -1) break;
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 2;
        pthread_cond_timedwait(&g_inputCond, &g_inputMutex, &ts);
    }
    pthread_mutex_unlock(&g_inputMutex);

    pthread_mutex_lock(&g_sfmlMutex);
    int result = g_weaponPickerResult;
    g_sfmlState = 0;
    pthread_mutex_unlock(&g_sfmlMutex);

    if (result == -2) return -2;
    if (result < 0 || result >= tmpCount) return -1;
    return tmpList[result].invSlot;
}

static void waitForEnterSFML() {
    pthread_mutex_lock(&g_inputMutex);
    while (getRunning() && g_state->gameRunning) {
        pthread_mutex_lock(&g_sfmlMutex);
        int st = g_sfmlState;
        pthread_mutex_unlock(&g_sfmlMutex);
        if (st == 0) break; // SFML thread cleared it on Enter
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 2;
        pthread_cond_timedwait(&g_inputCond, &g_inputMutex, &ts);
    }
    pthread_mutex_unlock(&g_inputMutex);
}


// TURN WATCHER THREAD
static void* turnWatcherThread(void*) {
    while (getRunning() && g_state->gameRunning) {
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 1;
        sem_timedwait(&g_state->hipActionSem, &ts);
        // Wake both the player turn wait loop and the input wait loop
        pthread_mutex_lock(&g_turnMutex);
        pthread_cond_broadcast(&g_turnCond);
        pthread_mutex_unlock(&g_turnMutex);
        pthread_mutex_lock(&g_inputMutex);
        pthread_cond_broadcast(&g_inputCond);
        pthread_mutex_unlock(&g_inputMutex);
    }
    return nullptr;
}

// POST ACTION
static void postAction(int playerId, int actionType, int targetId, int weaponIdx) {
    sem_wait(&g_state->globalTurnSem);
    
    g_shm->lockAction();
    g_state->pendingAction.entityId = playerId;
    g_state->pendingAction.entityType = 0;
    g_state->pendingAction.actionType = actionType;
    g_state->pendingAction.targetId = targetId;
    g_state->pendingAction.weaponIndex = weaponIdx;
    g_state->pendingAction.isReady = 1;
    g_state->guiWaitingForInput = 0;
    g_shm->unlockAction();
    sem_post(&g_state->arbiterSemaphore);
}


// SHOW INVENTORY 
static void showInventory(Entity* p) {
    clearScreen();
    showHeader();
    printf("\n");
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    printf("                         INVENTORY                                 \n");
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    printf("Player: %s\n", p->name);
    printf("Slots used: %d / 20\n", p->inventoryUsedSlots);
    printf("\n");
    
    printf("PRIMARY INVENTORY:\n");
    int displaySlot = 1;
    for (int i = 0; i < INVENTORY_SIZE; i++) {
        if (p->inventory[i].slotSize == 0) continue;
        bool isStart = (i == 0) || (p->inventory[i-1].slotSize == 0) ||
                       (strcmp(p->inventory[i-1].name, p->inventory[i].name) != 0);
        if (!isStart) continue;
        printf("  %d. %s (DMG:%d, Size:%d)%s\n", 
               displaySlot++, p->inventory[i].name, p->inventory[i].damage, 
               p->inventory[i].slotSize, p->inventory[i].isArtifact ? " [ARTIFACT]" : "");
    }
    
    printf("\nLONG TERM STORAGE:\n");
    for (int i = 0; i < p->longTermCount && i < 10; i++) {
        printf("  %d. %s (DMG:%d)\n", i, p->longTermStorage[i].name, p->longTermStorage[i].damage);
    }
    printf("\n");
}


// SHOW TURN MENU
static void showTurnMenu(Entity* P, int numEnemies, int enemyIndices[]) {
    clearScreen();
    showHeader();
    
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    printf("                          YOUR TURN                                \n");
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    printf("\n");
    printf("PLAYER: %s | HP: %d/%d | STAMINA: %d/%d | DMG: %d\n", 
           P->name, P->hp, P->maxHp, P->currentStamina, P->maxStamina, P->damage);
    if (P->hasSolarCore && P->hasLunarBlade) {
        printf("★ ULTIMATE READY! (Solar Core + Lunar Blade) ★\n");
    }
    printf("\n");
    
    printf("ENEMIES:\n");
    for (int i = 0; i < numEnemies; i++) {
        int eid = enemyIndices[i];
        printf("  %d. %s (HP: %d/%d)%s\n", i+1, g_state->enemies[eid].name,
               g_state->enemies[eid].hp, g_state->enemies[eid].maxHp,
               g_state->enemies[eid].hasEquippedWeapon ? " [ARMED]" : "");
    }
    printf("\n");
    printf("ACTIONS: 1=Strike 2=Exhaust 3=Use Weapon 4=Swap In 5=Heal 6=Skip 7=Inventory 8=Quit\n");
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    printf("Use SFML window for input!\n");
    fflush(stdout);
}


// PLAYER THREAD
static void* playerThread(void* arg) {
    int playerId = *(int*)arg;
    
    while (getRunning() && g_state->gameRunning) {
        // Stun check
        if (getStunReceived() && g_state->stunnedPlayer == playerId) {
            setStunReceived(0);
            write(STDOUT_FILENO, "[HIP] Player stunned\n", 21);
            raise(SIGSTOP);
            write(STDOUT_FILENO, "[HIP] Player resumed\n", 21);
        }
        
        pthread_mutex_lock(&g_turnMutex);
        while (getRunning() && g_state->gameRunning) {
            g_shm->lockState();
            // Use playerOwner to determine which HIP process owns this player (0=HIP1, 1=HIP2)
            bool isPlayerTurn = (g_state->currentTurnOwner == 0);      
            bool isMyPlayer = (g_state->currentEntityId  == playerId); 
            bool iOwnThisPlayer = (g_state->playerOwner[playerId] == g_hipOwnerIndex); 
            bool myTurn = isPlayerTurn && isMyPlayer && iOwnThisPlayer;
            bool alive = g_state->players[playerId].isAlive;
            bool stunned = g_state->players[playerId].isStunned;
            bool fullStam = (g_state->players[playerId].currentStamina >= g_state->players[playerId].maxStamina);
            bool pending = g_state->pendingAction.isReady;
            bool inProg = g_state->turnInProgress;
            g_shm->unlockState();
            
            if (!alive) {
                pthread_mutex_unlock(&g_turnMutex);
                return nullptr;
            }
            if (myTurn && !stunned && fullStam && !pending && !inProg) break;
            pthread_cond_wait(&g_turnCond, &g_turnMutex);
        }
        pthread_mutex_unlock(&g_turnMutex);
        
        if (!getRunning() || !g_state->gameRunning) break;
        
        g_shm->lockState();
        // Use playerOwner for the validity check too
        bool isPlayerTurn2 = (g_state->currentTurnOwner == 0);
        bool isMyPlayer2 = (g_state->currentEntityId  == playerId);
        bool iOwnThisPlayer2 = (g_state->playerOwner[playerId] == g_hipOwnerIndex);
        bool valid = (isPlayerTurn2 && isMyPlayer2 && iOwnThisPlayer2 &&
                      g_state->players[playerId].isAlive &&
                      !g_state->players[playerId].isStunned &&
                      g_state->players[playerId].currentStamina >= g_state->players[playerId].maxStamina &&
                      !g_state->pendingAction.isReady && !g_state->turnInProgress && g_state->gameRunning);
        if (!valid) {
            g_shm->unlockState();
            continue;
        }
        
        // Weapon drop prompt
        if (g_state->hasWeaponDrop && g_state->currentDrop.isAvailable &&
            !g_state->currentDrop.pickedUp) {
            
            clearScreen();
            showHeader();
            printf("\n!!! WEAPON DROP: %s (DMG:%d, Size:%d) !!!\n", 
                   g_state->currentDrop.weapon.name,
                   g_state->currentDrop.weapon.damage,
                   g_state->currentDrop.weapon.slotSize);
            printf("Pick up? (y/n)\n");
            fflush(stdout);
            g_shm->unlockState();
            
            char answer = readYNFromBufferSFML(g_state->currentDrop.weapon.name);
            
            g_shm->lockState();
            if (answer == 'y') {
                postAction(playerId, ACTION_PICKUP_WEAPON, -1, -1);
                g_shm->unlockState();
                usleep(400000);
                continue;
            } else if (answer == 'n') {
                postAction(playerId, ACTION_ENEMY_PICKUP, -1, -1);
                g_shm->unlockState();
                usleep(400000);
                continue;
            }
        }
        
        // Build enemy list
        int enemyIndices[MAX_ENEMIES];
        int numEnemies = 0;
        for (int i = 0; i < g_state->numEnemies; i++)
            if (g_state->enemies[i].isAlive)
                enemyIndices[numEnemies++] = i;
        
        Entity& P = g_state->players[playerId];
        
        // Update the SFML menu snapshot so the input window shows current game info
        {
            SfmlMenuSnapshot snap;
            strncpy(snap.playerName, P.name, sizeof(snap.playerName) - 1);
            snap.playerName[sizeof(snap.playerName)-1] = '\0';
            snap.playerHp = P.hp;
            snap.playerMaxHp = P.maxHp;
            snap.playerStamina = P.currentStamina;
            snap.playerMaxStamina = P.maxStamina;
            snap.playerDamage = P.damage;
            snap.playerUltimate = P.hasSolarCore && P.hasLunarBlade;
            snap.numEnemies = numEnemies;
            snap.activePlayerId = playerId;
            for (int i = 0; i < numEnemies; i++) {
                int eid = enemyIndices[i];
                strncpy(snap.enemyName[i], g_state->enemies[eid].name, 31);
                snap.enemyName[i][31] = '\0';
                snap.enemyHp[i] = g_state->enemies[eid].hp;
                snap.enemyMaxHp[i] = g_state->enemies[eid].maxHp;
                snap.enemyArmed[i] = g_state->enemies[eid].hasEquippedWeapon;
            }
            pthread_mutex_lock(&g_menuSnapMutex);
            g_menuSnap = snap;
            pthread_mutex_unlock(&g_menuSnapMutex);
        }
        
        showTurnMenu(&P, numEnemies, enemyIndices);
        g_shm->unlockState();
        
        int choice = readNumberFromBufferSFML();
        if (choice == 8) {
            printf("Quitting...\n");
            kill(g_state->arbiterPid, SIGTERM);
            setRunning(0);
            return nullptr;
        }
        
        g_shm->lockState();
        
        // Handle Inventory (choice 7)
        if (choice == 7) {
            // Show inventory in BOTH terminal and SFML window
            showInventory(&g_state->players[playerId]);
            
            Entity& inv = g_state->players[playerId];
            SfmlMenuSnapshot snapInv;
            pthread_mutex_lock(&g_menuSnapMutex);
            snapInv = g_menuSnap;
            pthread_mutex_unlock(&g_menuSnapMutex);
            
            snapInv.inventoryUsedSlots = inv.inventoryUsedSlots;
            int pc = 0;
            for (int s = 0; s < INVENTORY_SIZE && pc < 20; s++) {
                if (inv.inventory[s].slotSize == 0) continue;
                
                bool isStart = (s == 0) ||
                               (inv.inventory[s-1].slotSize == 0) ||
                               (strcmp(inv.inventory[s-1].name, inv.inventory[s].name) != 0);
                if (!isStart) continue;
                strncpy(snapInv.primaryInventory[pc].name, inv.inventory[s].name, 31);
                snapInv.primaryInventory[pc].name[31] = '\0';
                snapInv.primaryInventory[pc].damage    = inv.inventory[s].damage;
                snapInv.primaryInventory[pc].slotSize  = inv.inventory[s].slotSize;
                snapInv.primaryInventory[pc].isArtifact= inv.inventory[s].isArtifact;
                pc++;
            }
            snapInv.primaryCount = pc;
            
            int lc = 0;
            for (int j = 0; j < inv.longTermCount && j < 10; j++) {
                strncpy(snapInv.longTermStorage[lc].name, inv.longTermStorage[j].name, 31);
                snapInv.longTermStorage[lc].name[31] = '\0';
                snapInv.longTermStorage[lc].damage = inv.longTermStorage[j].damage;
                lc++;
            }
            snapInv.longTermCount = lc;
            
            pthread_mutex_lock(&g_menuSnapMutex);
            g_menuSnap = snapInv;
            pthread_mutex_unlock(&g_menuSnapMutex);
            
            // Set SFML state to 7 so the SFML window renders it
            pthread_mutex_lock(&g_sfmlMutex);
            g_sfmlState = 7;
            pthread_mutex_unlock(&g_sfmlMutex);
            
            g_shm->unlockState();
            waitForEnterSFML();
            continue;
        }
        
        int target = -1;
        int weaponIdx = -1;
        int goBack = 0;
        
        if (choice == 3) {
            while (getRunning() && g_state->gameRunning) {
                if (numEnemies > 0) {
                    g_shm->unlockState();
                    int t = readTargetFromBufferSFML(numEnemies);
                    g_shm->lockState();
                    if (t >= 1 && t <= numEnemies) {
                        target = enemyIndices[t - 1];
                    } else {
                        goBack = 1;
                        break;
                    }
                }
                g_shm->unlockState();
                weaponIdx = readWeaponFromBufferSFML(playerId);
                g_shm->lockState();
                if (weaponIdx == -2) {
                    continue;
                }
                if (weaponIdx == -1) {
                    printf("No weapon selected (inventory empty or cancelled).\n");
                    goBack = 1;
                }
                break;
            }
        } else if (choice == 1 || choice == 2) {
            if (numEnemies > 0) {
                g_shm->unlockState();
                int t = readTargetFromBufferSFML(numEnemies);
                g_shm->lockState();
                if (t >= 1 && t <= numEnemies) {
                    target = enemyIndices[t - 1];
                } else {
                    goBack = 1;
                }
            }
        }
        
        if (goBack) {
            g_shm->unlockState();
            continue;
        }
        
        // For action 4 Swap In take first storage item
        if (choice == 4) {
            if (g_state->players[playerId].longTermCount > 0) {
                weaponIdx = 0;
            } else {
                printf("Storage empty!\n");
                g_shm->unlockState();
                continue;
            }
        }
        
        postAction(playerId, choice, target, weaponIdx);
        g_shm->unlockState();
        usleep(150000);
    }
    return nullptr;
}

// MAIN
int main(int argc, char* argv[]) {
    // Parse args for multiplayer
    int g_playerStart = -1;
    int g_playerEnd = -1;
    for (int i = 1; i < argc - 1; i++) {
        if (strcmp(argv[i], "--player-start") == 0)
            g_playerStart = atoi(argv[i+1]);
        else if (strcmp(argv[i], "--player-end") == 0)
            g_playerEnd = atoi(argv[i+1]);
    }
    bool isHip2 = (g_playerStart > 0);
    g_isHip2 = isHip2;
    g_hipOwnerIndex = isHip2 ? 1 : 0;
    
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = signalHandler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGTERM, &sa, nullptr);
    sigaction(SIGUSR1, &sa, nullptr);
    signal(SIGPIPE, SIG_IGN);
    
    sleep(1);
    
    // Connect to shared memory
    int connected = 0;
    for (int retry = 0; retry < 10 && !connected; retry++) {
        try {
            g_shm = new SharedMemoryManager(SHM_NAME, 0);
            connected = 1;
        } catch (const char*) {
            sleep(1);
        }
    }
    if (!connected) {
        fprintf(stderr, "HIP ERROR: Could not connect\n");
        return 1;
    }
    g_state = g_shm->getState();
    srand(g_state->rollNumber);
    
    if (g_isHip2) {
        g_shm->lockState();
        g_state->hip2Pid = getpid();
        g_shm->unlockState();
    }
    
    g_shm->lockState();
    int numPlayers = g_state->numPlayers;
    g_shm->unlockState();
    
    int firstPlayer = (g_playerStart >= 0) ? g_playerStart : 0;
    int lastPlayer = (g_playerEnd >= 0) ? g_playerEnd : numPlayers - 1;
    
    clearScreen();
    showHeader();
    printf("Connected to shared memory\n");
    printf("SFML Input Window Active!\n");
    printf("Waiting for game to start...\n");
    fflush(stdout);
    
    // Initialize SFML menu snapshot with safe defaults
    memset(&g_menuSnap, 0, sizeof(g_menuSnap));
    snprintf(g_menuSnap.playerName, sizeof(g_menuSnap.playerName), "Player");
    g_menuSnap.activePlayerId = firstPlayer;
    
    // Start SFML input window
    pthread_create(&g_sfmlThread, nullptr, sfmlInputThread, nullptr);
    pthread_create(&g_watcherThread, nullptr, turnWatcherThread, nullptr);
    
    int managedCount = 0;
    for (int i = firstPlayer; i <= lastPlayer && i < numPlayers; i++) {
        g_playerIds[managedCount] = i;
        pthread_create(&g_playerThreads[managedCount], nullptr, playerThread, &g_playerIds[managedCount]);
        managedCount++;
    }
    
    for (int i = 0; i < managedCount; i++)
        pthread_join(g_playerThreads[i], nullptr);
    
    setRunning(0);
    pthread_mutex_lock(&g_turnMutex);
    pthread_cond_broadcast(&g_turnCond);
    pthread_mutex_unlock(&g_turnMutex);
    
    pthread_join(g_watcherThread, nullptr);
    pthread_cancel(g_sfmlThread);
    pthread_join(g_sfmlThread, nullptr);
    
    if (g_state && g_state != (GameState*)-1) {
        shmdt((void*)g_state);
        g_state = nullptr;
    }
    
    delete g_shm;
    printf("HIP Exiting.\n");
    return 0;
}
