#ifndef GAME_STATE_H
#define GAME_STATE_H

#include <semaphore.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>

/* Limits */
#define MAX_PLAYERS 4
#define MAX_ENEMIES 9
#define MAX_ARTIFACTS 3
#define INVENTORY_SIZE 20
#define LONG_TERM_STORAGE 50
#define MAX_ACTION_LOG 20

/* Resource types for deadlock detection */
#define RESOURCE_SOLAR_CORE   0
#define RESOURCE_LUNAR_BLADE  1
#define RESOURCE_ECLIPSE_RELIC 2
#define NUM_RESOURCES 3

/* Memory allocation tracking for inventory management */
#define MAX_ALLOCATIONS 100

struct AllocationRecord {
    int startSlot;
    int size;
    int weaponId;
    char weaponName[32];
    int isActive;
};

/* Input buffer for terminal input from HIP processes */
#define INPUT_BUF_SIZE 64
struct InputBuffer {
    char tokens[INPUT_BUF_SIZE][16];
    int head;
    int tail;
    sem_t dataReady;
    pthread_mutex_t mutex;
};

/* Weapon structure with contiguous slot allocation */
struct Weapon {
    char name[32];
    int slotSize;
    int damage;
    int id;
    int isArtifact;
};

/* Resource tracking for artifact deadlock detection */
struct ResourceInfo {
    int heldBy;
    int holderType;
    char name[32];
};

/* Entity structure Player or Enemy with stamina based turn scheduling */
struct Entity {
    int id;
    char name[32];
    int hp;
    int maxHp;
    int damage;
    int speed;
    int currentStamina;
    int maxStamina;
    float staminaAccum;   
    int isStunned;
    time_t stunEndTime;
    int isAlive;
    Weapon inventory[INVENTORY_SIZE];
    int inventoryUsedSlots;
    Weapon longTermStorage[LONG_TERM_STORAGE];
    int longTermCount;
    int hasSolarCore;
    int hasLunarBlade;
    int hasEclipseRelic;
    Weapon equippedWeapon;
    int hasEquippedWeapon;
    
    // Resource management
    int holding[NUM_RESOURCES];
    int waitingFor;
    int waitingForEntityId;
    int waitingForEntityType;
};

/* Legacy artifact structure */
struct Artifact {
    char name[32];
    int id;
    int isHeld;
    int holderId;
    int holderType;
    pid_t holderPid;
};

/* Action type definitions for turn actions */
#define ACTION_ATTACK_STRIKE 1    // Basic attack dealing base damage
#define ACTION_ATTACK_EXHAUST 2   // Reduce enemy stamina
#define ACTION_USE_WEAPON 3       // Attack using weapon from inventory
#define ACTION_SWAP_IN 4          // Move weapon from storage to inventory
#define ACTION_HEAL 5             // Restore 10% of max HP
#define ACTION_SKIP 6             // End turn, keep 50% stamina
#define ACTION_PICKUP_WEAPON 7    // Pick up dropped weapon
#define ACTION_PICKUP_ECLIPSE 8   // Special pickup for Eclipse Relic
#define ACTION_ENEMY_PICKUP 9     // Enemy takes weapon if player refuses

/* Pending action queued by HIP/ASP for arbiter execution */
struct PendingAction {
    int entityId;
    int entityType;
    int actionType;
    int targetId;
    int weaponIndex;
    int isReady;
};

/* Action log entry for UI display */
struct ActionLogEntry {
    char message[256];
    time_t timestamp;
};

/* Weapon drop from defeated enemy */
struct WeaponDrop {
    Weapon weapon;
    int isAvailable;
    int enemyId;
    int turnDropped;
    int pickedUp;
    float floatingY;
    float targetX;
    float targetY;
    int animating;
    int animationStep;
};

/* Main game state shared between all processes */
struct GameState {
    // Synchronization variables
    pthread_mutex_t stateMutex;
    pthread_mutex_t actionMutex;
    pthread_mutex_t logMutex;
    sem_t arbiterSemaphore;
    sem_t hipActionSem;
    sem_t aspActionSem;
    sem_t globalTurnSem;  

    // Turnaround time tracking
    time_t turnStartTime;
    double totalTurnaroundTime;
    
    // Players
    Entity players[MAX_PLAYERS];
    int numPlayers;
    int currentPlayerIndex;
    
    // Enemies
    Entity enemies[MAX_ENEMIES];
    int numEnemies;
    
    // Artifacts
    Artifact artifacts[MAX_ARTIFACTS];
    int numArtifacts;
    
    // Weapon drop
    WeaponDrop currentDrop;
    int hasWeaponDrop;
    
    // Turn management
    int currentTurnOwner;
    int currentEntityId;
    int turnInProgress;
    int waitingForAction;
    
    // Pending action
    PendingAction pendingAction;
    
    // Game status
    int gameRunning;
    int gameWinner;
    int enemiesKilled;
    int totalTurns;
    
    // Deadlock detection
    int deadlockDetected;
    int deadlockVictimEntity;
    int deadlockVictimType;

    // Eclipse relic event
    int eclipseRelicSpawned;
    int eclipseRelicOnGround;
    
    // Process IDs
    pid_t hipPid;
    pid_t hip2Pid;       // Second HIP for multiplayer (0 if unused)
    pid_t aspPid;
    pid_t arbiterPid;
    
    // Multiplayer configuration
    int multiplayerMode;        // 1 = two separate HIPs
    int playerOwner[MAX_PLAYERS]; // 0 = HIP1, 1 = HIP2
    
    int rollNumber;
    
    // Action log
    ActionLogEntry actionLog[MAX_ACTION_LOG];
    int actionLogHead;
    int actionLogCount;
    
    // Stun mechanism
    int stunnedPlayer;
    time_t stunResumeTime;
    pthread_t stunnedPlayerThread;
    
    // GUI state
    int guiMenuSelection;
    int guiTargetSelection;
    int guiWeaponSelection;
    int guiWaitingForInput;
    int guiSelectedAction;
    int guiSelectedTarget;
    int guiSelectedWeapon;

    // Input buffers (one per HIP for multiplayer)
    InputBuffer inputBuf;
    InputBuffer inputBuf2;   // Used by HIP2 in multiplayer mode
    
    // Resource table
    ResourceInfo resources[NUM_RESOURCES];
    
    // Memory management tracking
    AllocationRecord allocations[MAX_ALLOCATIONS];
    int allocationCount;
    int totalFragments;
    int compactionCount;
    int eclipseRelicOffered;
};

#define SHM_NAME "/chrono_rift_shm"

#endif
