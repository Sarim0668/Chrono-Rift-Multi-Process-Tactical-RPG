/* manages game state, turn scheduling, deadlock detection, weapon drops, and render thread. */

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/time.h>
#include <semaphore.h>
#include <cmath>
#include <functional>
#include <SFML/Graphics.hpp>

#include "GameState.h"
#include "SharedMemoryManager.h"
#include "Weapons.h"


/* Forward declarations */
void addLog(const char* msg);
int swapOutWeapons(Entity* entity, int neededSlots);
void compactInventory(Weapon* inventory, int* usedSlots);


/* Mutex for damage flashes and UI globals */
pthread_mutex_t g_uiMutex = PTHREAD_MUTEX_INITIALIZER;


//GLOBAL VARIABLES
SharedMemoryManager* g_shm = nullptr;
GameState* g_st  = nullptr;
static int eclipseRelicEventDone = 0;
pid_t g_hipPid  = 0;
pid_t g_hip2Pid = 0;
pid_t g_aspPid  = 0;
int g_running = 1;
int g_rollNumber = 0;
static int g_eclipseRelicSpawnAttempted = 0;
static int g_relicSpawned = 0;  // Track if relic was ever spawned


/* SFML graphics resources */
sf::Font g_font;
bool g_fontLoaded = false;
sf::Texture g_backgroundTex;
sf::Sprite g_backgroundSprite;

sf::Texture g_stunTex;
sf::Texture g_weaponTextures[9];
sf::Texture g_iconTex[7];
sf::Sprite g_stunOverlay[MAX_PLAYERS];
sf::Sprite g_weaponDropSprite;
sf::Sprite g_actionIcons[7];

sf::Texture g_playerTex[MAX_PLAYERS];
sf::Texture g_enemyTex[MAX_ENEMIES];
sf::Sprite g_playerSprites[MAX_PLAYERS];
sf::Sprite g_enemySprites[MAX_ENEMIES];


/* Animation variables */
float g_weaponAnimX = 0, g_weaponAnimY = 0;
int g_weaponAnimating = 0;
int g_weaponAnimTarget = -1;
int g_weaponAnimStep = 0;
float g_floatingOffset = 0;
int g_attackAnimRequest = 0;
int g_attackAnimDone = 1;
int g_attackAnimAttackerType = -1;
int g_attackAnimAttackerId = -1;
int g_attackAnimTargetType = -1;
int g_attackAnimTargetId = -1;


/* Weapon drop dialog */
int g_showWeaponDialog = 0;
int g_weaponDialogSelection = 0;


/* Damage flash effects */
#define MAX_DAMAGE_FLASHES 20
struct DamageFlash {
    int entityId;
    int entityType;
    int damage;
    float timer;
    float shakeOffset;
    int active;
};
DamageFlash g_damageFlashes[MAX_DAMAGE_FLASHES];
int g_numDamageFlashes = 0;


static int g_stun_ended_flag = 0;
static int g_ultimate_ended_flag = 0;
static pthread_mutex_t g_flagMutex = PTHREAD_MUTEX_INITIALIZER;


//DEADLOCK DETECTION FUNCTIONS


/* Initialize resource table with all artifacts free */
void initResourceTable() {
    g_st->resources[RESOURCE_SOLAR_CORE].heldBy = -1;
    g_st->resources[RESOURCE_SOLAR_CORE].holderType = -1;
    strcpy(g_st->resources[RESOURCE_SOLAR_CORE].name, "Solar Core");
    
    g_st->resources[RESOURCE_LUNAR_BLADE].heldBy = -1;
    g_st->resources[RESOURCE_LUNAR_BLADE].holderType = -1;
    strcpy(g_st->resources[RESOURCE_LUNAR_BLADE].name, "Lunar Blade");
    
    g_st->resources[RESOURCE_ECLIPSE_RELIC].heldBy = -1;
    g_st->resources[RESOURCE_ECLIPSE_RELIC].holderType = -1;
    strcpy(g_st->resources[RESOURCE_ECLIPSE_RELIC].name, "Eclipse Relic");
}

/* Initialize entity's resource holdings and waiting state */
void initEntityResources(Entity* e) {
    for (int i = 0; i < NUM_RESOURCES; i++) {
        e->holding[i] = 0;
    }
    e->waitingFor = -1;
    e->waitingForEntityId = -1;
}

/* Get resource ID from weapon name */
int getResourceIdFromWeapon(const char* weaponName) {
    if (strcmp(weaponName, "Solar Core") == 0) return RESOURCE_SOLAR_CORE;
    if (strcmp(weaponName, "Lunar Blade") == 0) return RESOURCE_LUNAR_BLADE;
    if (strcmp(weaponName, "Eclipse Relic") == 0) return RESOURCE_ECLIPSE_RELIC;
    return -1;
}

/* Check if a resource is currently free */
int isResourceFree(int resourceId) {
    return (g_st->resources[resourceId].heldBy == -1);
}

/* Assign resource to an entity */
void assignResource(int entityId, int entityType, int resourceId) {
    g_st->resources[resourceId].heldBy = entityId;
    g_st->resources[resourceId].holderType = entityType;
    
    if (entityType == 0) {
        g_st->players[entityId].holding[resourceId] = 1;
        g_st->players[entityId].waitingFor = -1;
        g_st->players[entityId].waitingForEntityId = -1;
    } else {
        g_st->enemies[entityId].holding[resourceId] = 1;
        g_st->enemies[entityId].waitingFor = -1;
        g_st->enemies[entityId].waitingForEntityId = -1;
    }
}

/* Release resource from an entity */
void releaseResource(int entityId, int entityType, int resourceId) {
    if (entityType == 0) {
        g_st->players[entityId].holding[resourceId] = 0;
    } else {
        g_st->enemies[entityId].holding[resourceId] = 0;
    }
    
    g_st->resources[resourceId].heldBy = -1;
    g_st->resources[resourceId].holderType = -1;
}

/* Try to acquire resource returns 1 if success and 0 if must wait */
int acquireResource(int entityId, int entityType, int resourceId) {
    if (isResourceFree(resourceId)) {
        assignResource(entityId, entityType, resourceId);
        return 1;
    } else {
        if (entityType == 0) {
            g_st->players[entityId].waitingFor = resourceId;
            g_st->players[entityId].waitingForEntityId = g_st->resources[resourceId].heldBy;
            g_st->players[entityId].waitingForEntityType = g_st->resources[resourceId].holderType;
        } else {
            g_st->enemies[entityId].waitingFor = resourceId;
            g_st->enemies[entityId].waitingForEntityId = g_st->resources[resourceId].heldBy;
            g_st->enemies[entityId].waitingForEntityType = g_st->resources[resourceId].holderType;
        }
        return 0;
    }
}

/* Get entity holding a resource */
int getResourceHolder(int resourceId) {
    return g_st->resources[resourceId].heldBy;
}

/* Resolve deadlock by force releasing victim's resources */
void resolveDeadlock(int victimEntityId, int victimType) {
    char msg[256];
    
    for (int r = 0; r < NUM_RESOURCES; r++) {
        if (victimType == 0) {
            if (g_st->players[victimEntityId].holding[r]) {
                snprintf(msg, sizeof(msg), "[DEADLOCK RESOLVED] Forcing %s to release %s",
                         g_st->players[victimEntityId].name,
                         g_st->resources[r].name);
                addLog(msg);
                printf("%s\n", msg);
                releaseResource(victimEntityId, victimType, r);
                
                Entity& p = g_st->players[victimEntityId];
                if (r == RESOURCE_SOLAR_CORE) p.hasSolarCore = 0;
                if (r == RESOURCE_LUNAR_BLADE) p.hasLunarBlade = 0;
                if (r == RESOURCE_ECLIPSE_RELIC) p.hasEclipseRelic = 0;
                
                for (int s = 0; s < INVENTORY_SIZE; s++) {
                    int rid = getResourceIdFromWeapon(p.inventory[s].name);
                    if (rid == r) {
                        int slotSize = p.inventory[s].slotSize;
                        for (int t = s; t < s + slotSize && t < INVENTORY_SIZE; t++) {
                            memset(&p.inventory[t], 0, sizeof(Weapon));
                        }
                        p.inventoryUsedSlots -= slotSize;
                    }
                }
            }
        } else {
            if (g_st->enemies[victimEntityId].holding[r]) {
                snprintf(msg, sizeof(msg), "[DEADLOCK RESOLVED] Forcing %s to release %s",
                         g_st->enemies[victimEntityId].name,
                         g_st->resources[r].name);
                addLog(msg);
                printf("%s\n", msg);
                releaseResource(victimEntityId, victimType, r);
                
                Entity& e = g_st->enemies[victimEntityId];
                e.hasEquippedWeapon = 0;
                memset(&e.equippedWeapon, 0, sizeof(Weapon));
                e.damage = (g_st->rollNumber / 10) % 10 + 10;
            }
        }
    }
    
    if (victimType == 0) {
        g_st->players[victimEntityId].waitingFor = -1;
        g_st->players[victimEntityId].waitingForEntityId = -1;
        g_st->players[victimEntityId].waitingForEntityType = -1;
    } else {
        g_st->enemies[victimEntityId].waitingFor = -1;
        g_st->enemies[victimEntityId].waitingForEntityId = -1;
        g_st->enemies[victimEntityId].waitingForEntityType = -1;
    }
    
    g_st->deadlockDetected = 1;
    g_st->deadlockVictimEntity = victimEntityId;
    g_st->deadlockVictimType = victimType;
    
    for (int i = 0; i < g_st->numPlayers; i++) {
        if (g_st->players[i].isAlive && g_st->players[i].waitingFor != -1) {
            int resId = g_st->players[i].waitingFor;
            if (g_st->resources[resId].heldBy == -1) {
                g_st->players[i].waitingFor = -1;
                g_st->players[i].waitingForEntityId = -1;
                g_st->players[i].waitingForEntityType = -1;
            }
        }
    }
    
    for (int i = 0; i < g_st->numEnemies; i++) {
        if (g_st->enemies[i].isAlive && g_st->enemies[i].waitingFor != -1) {
            int resId = g_st->enemies[i].waitingFor;
            if (g_st->resources[resId].heldBy == -1) {
                g_st->enemies[i].waitingFor = -1;
                g_st->enemies[i].waitingForEntityId = -1;
                g_st->enemies[i].waitingForEntityType = -1;
            }
        }
    }
}


//Uses DFS on wait-for graph to detect circular waits
 
void* deadlockDetectorThread(void*) {
    while (g_running && g_st->gameRunning) {
        sleep(1);
        
        pthread_mutex_lock(&g_st->stateMutex);
        
        int totalEntities = g_st->numPlayers + g_st->numEnemies;
        int waitFor[MAX_PLAYERS + MAX_ENEMIES];
        
        for (int i = 0; i < totalEntities; i++) {
            waitFor[i] = -1;
            
            int isPlayer = (i < g_st->numPlayers);
            Entity* entity;
            int entityId = i;
            
            if (isPlayer) {
                entity = &g_st->players[entityId];
            } else {
                entity = &g_st->enemies[entityId - g_st->numPlayers];
            }
            
            if (!entity->isAlive) continue;
            if (entity->waitingFor == -1) continue;
            
            int resourceWanted = entity->waitingFor;
            if (resourceWanted < 0 || resourceWanted >= NUM_RESOURCES) continue;
            
            int holderId = g_st->resources[resourceWanted].heldBy;
            int holderType = g_st->resources[resourceWanted].holderType;
            
            if (holderId == -1) continue;
            
            if (holderType == 0) {
                waitFor[i] = holderId;
            } else {
                waitFor[i] = g_st->numPlayers + holderId;
            }
        }
        
        int visited[MAX_PLAYERS + MAX_ENEMIES];
        int recStack[MAX_PLAYERS + MAX_ENEMIES];
        
        for (int i = 0; i < totalEntities; i++) {
            visited[i] = 0;
            recStack[i] = 0;
        }
        
        std::function<bool(int, int&, int&)> hasCycle = [&](int node, int& cycleStart, int& cycleEnd) -> bool {
            if (waitFor[node] == -1) return false;
            if (recStack[node]) {
                cycleStart = node;
                cycleEnd = waitFor[node];
                return true;
            }
            if (visited[node]) return false;
            
            visited[node] = 1;
            recStack[node] = 1;
            
            int next = waitFor[node];
            if (next >= 0 && next < totalEntities) {
                if (hasCycle(next, cycleStart, cycleEnd)) {
                    recStack[node] = 0;
                    return true;
                }
            }
            
            recStack[node] = 0;
            return false;
        };
        
        int cycleStart = -1, cycleEnd = -1;
        for (int i = 0; i < totalEntities; i++) {
            if (!visited[i] && waitFor[i] != -1) {
                if (hasCycle(i, cycleStart, cycleEnd)) {
                    char msg[128];
                    snprintf(msg, sizeof(msg), "[DEADLOCK] Circular wait detected in resource dependency graph");
                    addLog(msg);
                    printf("\n%s\n", msg);
                    
                    int victim = cycleStart;
                    int victimIsPlayer = (victim < g_st->numPlayers);
                    
                    if (victimIsPlayer) {
                        resolveDeadlock(victim, 0);
                    } else {
                        resolveDeadlock(victim - g_st->numPlayers, 1);
                    }
                    break;
                }
            }
        }
        
        pthread_mutex_unlock(&g_st->stateMutex);
    }
    return nullptr;
}

//SFML FUNCTIONS

//DAMAGE FLASH EFFECTS
void addDamageFlash(int entityId, int entityType, int damage) {
    pthread_mutex_lock(&g_uiMutex);
    if (g_numDamageFlashes >= MAX_DAMAGE_FLASHES) {
        pthread_mutex_unlock(&g_uiMutex);
        return;
    }
    g_damageFlashes[g_numDamageFlashes].entityId = entityId;
    g_damageFlashes[g_numDamageFlashes].entityType = entityType;
    g_damageFlashes[g_numDamageFlashes].damage = damage;
    g_damageFlashes[g_numDamageFlashes].timer = 2.0f;
    g_damageFlashes[g_numDamageFlashes].shakeOffset = 0;
    g_damageFlashes[g_numDamageFlashes].active = 1;
    g_numDamageFlashes++;
    pthread_mutex_unlock(&g_uiMutex);
}

void updateDamageFlashes(float deltaTime) {
    pthread_mutex_lock(&g_uiMutex);
    for (int i = 0; i < g_numDamageFlashes; i++) {
        if (g_damageFlashes[i].active) {
            g_damageFlashes[i].timer -= deltaTime;
            g_damageFlashes[i].shakeOffset = sin(g_damageFlashes[i].timer * 30) * 5;
            if (g_damageFlashes[i].timer <= 0) {
                for (int j = i; j < g_numDamageFlashes - 1; j++) {
                    g_damageFlashes[j] = g_damageFlashes[j + 1];
                }
                g_numDamageFlashes--;
                i--;
            }
        }
    }
    pthread_mutex_unlock(&g_uiMutex);
}

//Shake bar of the enemy to show the damage effect and also showing damage
float getShakeOffset(int entityId, int entityType) {
    pthread_mutex_lock(&g_uiMutex);
    for (int i = 0; i < g_numDamageFlashes; i++) {
        if (g_damageFlashes[i].active && 
            g_damageFlashes[i].entityId == entityId && 
            g_damageFlashes[i].entityType == entityType) {
            float off = g_damageFlashes[i].shakeOffset;
            pthread_mutex_unlock(&g_uiMutex);
            return off;
        }
    }
    pthread_mutex_unlock(&g_uiMutex);
    return 0;
}

int getDamageNumber(int entityId, int entityType) {
    pthread_mutex_lock(&g_uiMutex);
    for (int i = 0; i < g_numDamageFlashes; i++) {
        if (g_damageFlashes[i].active && 
            g_damageFlashes[i].entityId == entityId && 
            g_damageFlashes[i].entityType == entityType) {
            int dmg = g_damageFlashes[i].damage;
            pthread_mutex_unlock(&g_uiMutex);
            return dmg;
        }
    }
    pthread_mutex_unlock(&g_uiMutex);
    return 0;
}

float getDamageTimer(int entityId, int entityType) {
    pthread_mutex_lock(&g_uiMutex);
    for (int i = 0; i < g_numDamageFlashes; i++) {
        if (g_damageFlashes[i].active && 
            g_damageFlashes[i].entityId == entityId && 
            g_damageFlashes[i].entityType == entityType) {
            float t = g_damageFlashes[i].timer;
            pthread_mutex_unlock(&g_uiMutex);
            return t;
        }
    }
    pthread_mutex_unlock(&g_uiMutex);
    return 0;
}

void startAttackAnimation(int attackerType, int attackerId, int targetType, int targetId) {
    pthread_mutex_lock(&g_uiMutex);
    g_attackAnimAttackerType = attackerType;
    g_attackAnimAttackerId = attackerId;
    g_attackAnimTargetType = targetType;
    g_attackAnimTargetId = targetId;
    g_attackAnimDone = 0;
    g_attackAnimRequest = 1;
    pthread_mutex_unlock(&g_uiMutex);

    for (int i = 0; i < 180 && g_running && g_st && g_st->gameRunning; i++) {
        pthread_mutex_lock(&g_uiMutex);
        int done = g_attackAnimDone;
        pthread_mutex_unlock(&g_uiMutex);
        if (done) break;
        usleep(10000);
    }

    pthread_mutex_lock(&g_uiMutex);
    g_attackAnimRequest = 0;
    g_attackAnimDone = 1;
    pthread_mutex_unlock(&g_uiMutex);
}

/* Add entry to action log */
void addLog(const char* msg) { if (g_shm) g_shm->addToActionLog(msg); }

/* Signal handlers */
void onSIGTERM(int) { g_running = 0; if (g_st) g_st->gameRunning = 0; }

/* Timer state — protected by g_flagMutex */
static int g_stunTimerActive     = 0;
static int g_ultimateTimerActive = 0;
static time_t g_stunDeadline     = 0;
static time_t g_ultimateDeadline = 0;

/* Rearm timer for next stun/ultimate expiry */
static void rearmTimer() {
    time_t now = time(nullptr);
    time_t soonest = 0;

    pthread_mutex_lock(&g_flagMutex);
    if (g_stunTimerActive && g_stunDeadline > now) {
        time_t d = g_stunDeadline - now;
        if (soonest == 0 || d < soonest) soonest = d;
    }
    if (g_ultimateTimerActive && g_ultimateDeadline > now) {
        time_t d = g_ultimateDeadline - now;
        if (soonest == 0 || d < soonest) soonest = d;
    }
    pthread_mutex_unlock(&g_flagMutex);

    struct itimerval tv;
    tv.it_interval.tv_sec  = 0;
    tv.it_interval.tv_usec = 0;
    if (soonest > 0) {
        tv.it_value.tv_sec  = soonest;
        tv.it_value.tv_usec = 0;
    } else {
        tv.it_value.tv_sec  = 0;
        tv.it_value.tv_usec = 0;
    }
    setitimer(ITIMER_REAL, &tv, nullptr);
}

/* SIGALRM handler sets flags for stun/ultimate expiry */
void onSIGALRM(int) {
    time_t now = time(nullptr);

    pthread_mutex_lock(&g_flagMutex);
    if (g_stunTimerActive && now >= g_stunDeadline) {
        g_stunTimerActive = 0;
        g_stun_ended_flag = 1;
    }

    if (g_ultimateTimerActive && now >= g_ultimateDeadline) {
        g_ultimateTimerActive = 0;
        g_ultimate_ended_flag = 1;
    }
    pthread_mutex_unlock(&g_flagMutex);

    rearmTimer();
}

/* Spawn a child process */
void spawnProcess(const char* exe, pid_t* pid, int giveStdin, const char* arg1 = nullptr, const char* arg2 = nullptr, const char* arg3 = nullptr, const char* arg4 = nullptr) {
    *pid = fork();
    if (*pid == 0) {
        int dn_w = open("/dev/null", O_WRONLY);
        if (dn_w != -1) { dup2(dn_w, STDERR_FILENO); close(dn_w); }
        if (!giveStdin) {
            int dn_r = open("/dev/null", O_RDONLY);
            if (dn_r != -1) { 
            dup2(dn_r, STDIN_FILENO); 
            close(dn_r); 
            }
        }
        if (arg1 && arg2 && arg3 && arg4)
            execl(exe, exe, arg1, arg2, arg3, arg4, nullptr);
        else
            execl(exe, exe, nullptr);
        exit(1);
    }
}

/* Spawn new wave of enemies */
void spawnEnemyWave() {
    int lastTwo = g_rollNumber % 100;
    int secondLast = (g_rollNumber / 10) % 10;
    int count = 2 + (rand() % 8);
    g_st->numEnemies = count;
    for (int i = 0; i < count; i++) {
        Entity& e = g_st->enemies[i];
        memset(&e, 0, sizeof(Entity));
        e.id = i;
        snprintf(e.name, 32, "E%d", g_st->enemiesKilled + i + 1);
        e.hp = lastTwo + 50 + (rand() % 151);
        e.maxHp = e.hp;
        e.damage = secondLast + 10;
        e.speed = 10 + (rand() % 21);
        e.maxStamina = 150;
        e.currentStamina = 0;
        e.staminaAccum = 0.0f;
        e.isAlive = 1;
        e.isStunned = 0;
        e.hasEquippedWeapon = 0;
        memset(&e.equippedWeapon, 0, sizeof(Weapon));
        initEntityResources(&e);
        
        int cols = 3;
        int row = i / cols;
        int col = i % cols;
        float x = 790 + col * 95;
        float y = 80 + row * 100;
        g_enemySprites[i].setPosition(x, y);
    }
    char msg[64];
    snprintf(msg, sizeof(msg), "*** NEW WAVE: %d enemies! ***", count);
    addLog(msg);
    printf("\n%s\n", msg); fflush(stdout);
}

/* Get texture index for weapon sprite */
int getWeaponTextureIndex(const char* name) {
    if (strcmp(name, "Solar Core") == 0) return 0;
    if (strcmp(name, "Lunar Blade") == 0) return 1;
    if (strcmp(name, "Iron Halberd") == 0) return 2;
    if (strcmp(name, "Venom Dagger") == 0) return 3;
    if (strcmp(name, "Thunderstaff") == 0) return 4;
    if (strcmp(name, "Obsidian Axe") == 0) return 5;
    if (strcmp(name, "Frostbow") == 0) return 6;
    if (strcmp(name, "Splinter Stick") == 0) return 7;
    if (strcmp(name, "Eclipse Relic") == 0) return 8;
    return 2;
}


//WEAPON DROP AND PICKUP FUNCTIONS


/* Handle weapon drop when enemy dies */
void handleWeaponDrop(int enemyId) {
    if (g_st->hasWeaponDrop) return;
    if (enemyId < 0 || enemyId >= g_st->numEnemies || g_st->enemies[enemyId].isAlive) return;

    if (rand() % 100 < 15)// 15 orignal 
    {
        for (int attempt = 0; attempt < 2; attempt++) {
            int artIdx = (attempt == 0) ? 0 : 1;
            int resourceId = (artIdx == 0) ? RESOURCE_SOLAR_CORE : RESOURCE_LUNAR_BLADE;
            
            if (isResourceFree(resourceId)) {
                Weapon drop = getArtifactDrop(artIdx);
                g_st->hasWeaponDrop = 1;
                g_st->currentDrop.weapon = drop;
                g_st->currentDrop.isAvailable = 1;
                g_st->currentDrop.enemyId = enemyId;
                g_st->currentDrop.pickedUp = 0;
                
                int cols = 3;
                int row = enemyId / cols;
                int col = enemyId % cols;
                float ex = 790 + col * 95 + 40;
                float ey = 80 + row * 100 + 40;
                g_weaponDropSprite.setPosition(ex, ey);
                g_weaponDropSprite.setScale(0.5f, 0.5f);
                
                int texIdx = getWeaponTextureIndex(drop.name);
                g_weaponDropSprite.setTexture(g_weaponTextures[texIdx]);
                
                pthread_mutex_lock(&g_uiMutex);
                g_showWeaponDialog = 1;
                g_weaponDialogSelection = 0;
                pthread_mutex_unlock(&g_uiMutex);
                
                char msg[128];
                snprintf(msg, sizeof(msg), "*** ARTIFACT DROP: %s! (DMG:%d, Size:%d) ***",
                         drop.name, drop.damage, drop.slotSize);
                addLog(msg);
                printf("\n%s\n", msg); fflush(stdout);
                return;
            }
        }
    }

    if (rand() % 100 < 40) {
        Weapon drop = getRandomWeaponDrop();
        g_st->hasWeaponDrop = 1;
        g_st->currentDrop.weapon = drop;
        g_st->currentDrop.isAvailable = 1;
        g_st->currentDrop.enemyId = enemyId;
        g_st->currentDrop.pickedUp = 0;
        
        int cols = 3;
        int row = enemyId / cols;
        int col = enemyId % cols;
        float ex = 790 + col * 95 + 40;
        float ey = 80 + row * 100 + 40;
        g_weaponDropSprite.setPosition(ex, ey);
        g_weaponDropSprite.setScale(0.5f, 0.5f);
        
        int texIdx = getWeaponTextureIndex(drop.name);
        g_weaponDropSprite.setTexture(g_weaponTextures[texIdx]);
        
        pthread_mutex_lock(&g_uiMutex);
        g_showWeaponDialog = 1;
        g_weaponDialogSelection = 0;
        pthread_mutex_unlock(&g_uiMutex);
        
        char msg[128];
        snprintf(msg, sizeof(msg), "WEAPON DROP: %s dropped: %s! (DMG:%d, Size:%d)", 
                 g_st->enemies[enemyId].name, drop.name, drop.damage, drop.slotSize);
        addLog(msg);
        printf("\n%s\n", msg);
        fflush(stdout);
    }
}

/* Handle player picking up weapon */
void handleWeaponPickup(int playerId) {
    char msg[256];
    
    if (!g_st->hasWeaponDrop || !g_st->currentDrop.isAvailable) {
        return;
    }
    
    if (g_st->currentDrop.pickedUp) {
        return;
    }
    
    Entity& player = g_st->players[playerId];
    Weapon pickedWeapon = g_st->currentDrop.weapon;
    
    int neededSlots = pickedWeapon.slotSize;
    int freeSlots = INVENTORY_SIZE - player.inventoryUsedSlots;
    
    printf("\n=== PICKUP ATTEMPT ===\n");
    printf("Player: %s\n", player.name);
    printf("Weapon: %s (Size: %d, Damage: %d)\n", pickedWeapon.name, neededSlots, pickedWeapon.damage);
    printf("Inventory: %d/%d slots used\n", player.inventoryUsedSlots, INVENTORY_SIZE);
    printf("Free slots: %d, Need: %d\n", freeSlots, neededSlots);
    
    if (freeSlots < neededSlots) {
        printf("\n⚠️ NOT ENOUGH SPACE! Attempting to swap out weapons...\n");
        
        int swapResult = swapOutWeapons(&player, neededSlots - freeSlots);
        
        if (swapResult) {
            compactInventory(player.inventory, &player.inventoryUsedSlots);
            freeSlots = INVENTORY_SIZE - player.inventoryUsedSlots;
            printf("✅ Swap out successful! Now have %d free slots\n", freeSlots);
        } else {
            printf("❌ Swap out failed - not enough weapons to swap\n");
            pthread_mutex_lock(&g_uiMutex);
            g_showWeaponDialog = 0;
            g_weaponDialogSelection = 0;
            pthread_mutex_unlock(&g_uiMutex);
            
            g_st->hasWeaponDrop = 0;
            g_st->currentDrop.isAvailable = 0;
            g_st->currentDrop.enemyId = -1;
            memset(&g_st->currentDrop.weapon, 0, sizeof(Weapon));
            
            snprintf(msg, sizeof(msg), "❌ %s: No space for %s and couldn't swap out weapons!", 
                     player.name, pickedWeapon.name);
            addLog(msg);
            printf("%s\n", msg);
            return;
        }
    }
    
    int success = pickupWeaponTracked(&player, &pickedWeapon, g_st);
    
    pthread_mutex_lock(&g_uiMutex);
    g_showWeaponDialog = 0;
    g_weaponDialogSelection = 0;
    pthread_mutex_unlock(&g_uiMutex);
    
    g_st->hasWeaponDrop = 0;
    g_st->currentDrop.isAvailable = 0;
    g_st->currentDrop.enemyId = -1;
    g_st->eclipseRelicOnGround = 0;
    memset(&g_st->currentDrop.weapon, 0, sizeof(Weapon));
    
    if (success) {
        g_st->currentDrop.pickedUp = 1;
        
        pthread_mutex_lock(&g_uiMutex);
        g_weaponAnimating = 1;
        g_weaponAnimTarget = playerId;
        g_weaponAnimStep = 0;
        g_weaponAnimX = g_weaponDropSprite.getPosition().x;
        g_weaponAnimY = g_weaponDropSprite.getPosition().y;
        pthread_mutex_unlock(&g_uiMutex);
        
        snprintf(msg, sizeof(msg), "🎒 %s picked up %s! (DMG:%d, Size:%d)", 
                 player.name, pickedWeapon.name, pickedWeapon.damage, pickedWeapon.slotSize);
        addLog(msg);
        printf("\n%s\n", msg);
        
        if (pickedWeapon.isArtifact) {
            int resourceId = getResourceIdFromWeapon(pickedWeapon.name);
            if (resourceId != -1) {
                pthread_mutex_lock(&g_st->stateMutex);
                acquireResource(playerId, 0, resourceId);
                pthread_mutex_unlock(&g_st->stateMutex);
            }
            
            if (strcmp(pickedWeapon.name, "Solar Core") == 0) {
                player.hasSolarCore = 1;
                addLog("Solar Core acquired!");
            }
            else if (strcmp(pickedWeapon.name, "Lunar Blade") == 0) {
                player.hasLunarBlade = 1;
                addLog("Lunar Blade acquired!");
            }
            else if (strcmp(pickedWeapon.name, "Eclipse Relic") == 0) {
                player.hasEclipseRelic = 1;
                g_st->eclipseRelicSpawned = 2;
                eclipseRelicEventDone = 1;
                addLog("Eclipse Relic acquired!");
            }
        }
    } else {
        snprintf(msg, sizeof(msg), "❌ %s: Still no space for %s after swap out! (needs %d slots)", 
                 player.name, pickedWeapon.name, pickedWeapon.slotSize);
        addLog(msg);
        printf("\n%s\n", msg);
        
        if (strcmp(pickedWeapon.name, "Eclipse Relic") == 0) {
            eclipseRelicEventDone = 1;
            g_st->eclipseRelicSpawned = 2;
        }
    }
    fflush(stdout);
}

/* Set stamina to a fixed integer value and sync float accumulator */
static inline void resetStamina(Entity* e, int value) {
    if (value < 0) value = 0;
    if (value > e->maxStamina) 
     value = e->maxStamina;
    e->currentStamina = value;
    e->staminaAccum = (float)value;
}

/* Handle enemy picking up weapon if player refuses */
void handleEnemyPickupWeapon() {
    if (!g_st->hasWeaponDrop || !g_st->currentDrop.isAvailable) {
        return;
    }
   
    if (g_st->currentDrop.pickedUp) {
        g_st->hasWeaponDrop = 0;
        g_st->currentDrop.isAvailable = 0;
        return;
    }
    
    pthread_mutex_lock(&g_uiMutex);
    g_showWeaponDialog = 0;
    pthread_mutex_unlock(&g_uiMutex);
    
    Weapon droppedWeapon = g_st->currentDrop.weapon;
    int dropEnemyId = g_st->currentDrop.enemyId;
    
    bool isEclipseRelic = (droppedWeapon.isArtifact && strcmp(droppedWeapon.name, "Eclipse Relic") == 0);

    int aliveEnemies[MAX_ENEMIES];
    int aliveCount = 0;
    
    for (int i = 0; i < g_st->numEnemies; i++) {
        if (g_st->enemies[i].isAlive && i != dropEnemyId) {
            aliveEnemies[aliveCount++] = i;
        }
    }
    
    if (aliveCount > 0) {
        int randomIndex = rand() % aliveCount;
        int enemyId = aliveEnemies[randomIndex];
        
        Entity& enemy = g_st->enemies[enemyId];
        int oldDamage = enemy.damage;
        
        enemy.equippedWeapon = droppedWeapon;
        enemy.hasEquippedWeapon = 1;
        enemy.damage = droppedWeapon.damage;
        
        g_st->currentDrop.pickedUp = 1;
        
        if (droppedWeapon.isArtifact) {
            int resourceId = getResourceIdFromWeapon(droppedWeapon.name);
            if (resourceId != -1) {
                acquireResource(enemyId, 1, resourceId);
            }
            addLog("⚠️ An enemy picked up an artifact! This will make the fight harder!");
            
            if (isEclipseRelic) {
                eclipseRelicEventDone = 1;
                g_st->eclipseRelicSpawned = 2;
                g_st->eclipseRelicOnGround = 0;
            }
        }
        
        char msg[256];
        snprintf(msg, sizeof(msg), "👹 %s picked up %s! (Damage: %d -> %d)", 
                 enemy.name, droppedWeapon.name, oldDamage, enemy.damage);
        addLog(msg);
        printf("\n%s\n", msg);
    } else {
        if (isEclipseRelic) {
            eclipseRelicEventDone = 1;
            g_st->eclipseRelicSpawned = 2;
            g_st->eclipseRelicOnGround = 0;
            addLog("Eclipse Relic vanished — no enemies to pick it up.");
            printf("\n*** Eclipse Relic has vanished! ***\n");
        } else {
            addLog("No enemies to pick up the weapon! It disappears.");
        }
    }
    
    g_st->hasWeaponDrop = 0;
    g_st->currentDrop.isAvailable = 0;
    g_st->currentDrop.enemyId = -1;
    g_st->currentDrop.pickedUp = 0;
    g_st->eclipseRelicOnGround = 0;
    memset(&g_st->currentDrop.weapon, 0, sizeof(Weapon));
    fflush(stdout);
}

/* Execute a pending action from HIP or ASP */
void executeAction(const PendingAction& a) {
    if (g_st->turnStartTime > 0) {
        double elapsed = difftime(time(nullptr), g_st->turnStartTime);
        g_st->totalTurnaroundTime += elapsed;
        char taMsg[96];
        snprintf(taMsg, sizeof(taMsg), "[TAT] Turn %d turnaround: %.1fs (cumulative: %.1fs)",
                 g_st->totalTurns + 1, elapsed, g_st->totalTurnaroundTime);
        addLog(taMsg);
        printf("%s\n", taMsg);
    }
    char msg[256];
    if (a.entityType == 0) {
        Entity& P = g_st->players[a.entityId];
        switch (a.actionType) {
        case ACTION_ATTACK_STRIKE: {
            if (a.targetId >= 0 && a.targetId < g_st->numEnemies && g_st->enemies[a.targetId].isAlive) {
                Entity& T = g_st->enemies[a.targetId];
                int damage = P.damage;
                startAttackAnimation(0, a.entityId, 1, a.targetId);
                T.hp -= damage;
                addDamageFlash(a.targetId, 1, damage);
                snprintf(msg, sizeof(msg), "%s strikes %s for %d!", P.name, T.name, damage);
                addLog(msg);
                if (T.hp <= 0) {
                    T.isAlive = 0;
                    g_st->enemiesKilled++;
                    sem_post(&g_st->aspActionSem);
                    
                    if (T.hasEquippedWeapon) {
                        char weaponLostMsg[128];
                        snprintf(weaponLostMsg, sizeof(weaponLostMsg), "💀 %s died with %s! Weapon lost forever!", 
                                 T.name, T.equippedWeapon.name);
                        addLog(weaponLostMsg);
                        if (T.equippedWeapon.isArtifact) {
                            int resourceId = getResourceIdFromWeapon(T.equippedWeapon.name);
                            if (resourceId != -1) {
                                releaseResource(T.id, 1, resourceId);
                            }
                        }
                        T.hasEquippedWeapon = 0;
                        memset(&T.equippedWeapon, 0, sizeof(Weapon));
                    }
                    
                    snprintf(msg, sizeof(msg), "%s defeated! (%d/10)", T.name, g_st->enemiesKilled);
                    addLog(msg);
                    handleWeaponDrop(a.targetId);
                }
            }
            resetStamina(&P, 0);
            break;
        }
        case ACTION_ATTACK_EXHAUST: {
            if (a.targetId >= 0 && a.targetId < g_st->numEnemies && g_st->enemies[a.targetId].isAlive) {
                Entity& T = g_st->enemies[a.targetId];
                startAttackAnimation(0, a.entityId, 1, a.targetId);
                T.currentStamina -= P.damage;
                if (T.currentStamina < 0) T.currentStamina = 0;
                T.staminaAccum = (float)T.currentStamina;
                snprintf(msg, sizeof(msg), "%s exhausts %s (-%d SP)!", P.name, T.name, P.damage);
                addLog(msg);
            }
            resetStamina(&P, 0);
            break;
        }
        case ACTION_USE_WEAPON: {
            if (a.weaponIndex >= 0 && a.weaponIndex < INVENTORY_SIZE &&
                P.inventory[a.weaponIndex].damage > 0 &&
                a.targetId >= 0 && a.targetId < g_st->numEnemies && g_st->enemies[a.targetId].isAlive) {
                
                Entity& T = g_st->enemies[a.targetId];
                int wdmg = P.inventory[a.weaponIndex].damage;
                char weaponName[32];
                strcpy(weaponName, P.inventory[a.weaponIndex].name);
                
                if (hasUltimateAbility(&P)) {
                    wdmg = 999;
                    addLog("ULTIMATE ABILITY activated!");
                    pthread_mutex_lock(&g_flagMutex);
                    int alreadyActive = g_ultimateTimerActive;
                    pthread_mutex_unlock(&g_flagMutex);
                    if (g_aspPid > 0 && !alreadyActive) {
                        kill(g_aspPid, SIGCONT);
                        usleep(50000);
                        kill(g_aspPid, SIGUSR1);
                        addLog("ASP suspended for 10 seconds (Ultimate)!");
                        pthread_mutex_lock(&g_flagMutex);
                        g_ultimateTimerActive = 1;
                        g_ultimateDeadline = time(nullptr) + 10;
                        pthread_mutex_unlock(&g_flagMutex);
                        rearmTimer();
                    }
                }
                
                startAttackAnimation(0, a.entityId, 1, a.targetId);
                T.hp -= wdmg;
                addDamageFlash(a.targetId, 1, wdmg);
                snprintf(msg, sizeof(msg), "%s uses %s on %s for %d DMG!", P.name, weaponName, T.name, wdmg);
                addLog(msg);
                printf("\n%s\n", msg);
                
                if (T.hp <= 0) {
                    T.isAlive = 0;
                    g_st->enemiesKilled++;
                    sem_post(&g_st->aspActionSem);
                    
                    if (T.hasEquippedWeapon) {
                        char weaponLostMsg[128];
                        snprintf(weaponLostMsg, sizeof(weaponLostMsg), "💀 %s died with %s! Weapon lost forever!", 
                                 T.name, T.equippedWeapon.name);
                        addLog(weaponLostMsg);
                        if (T.equippedWeapon.isArtifact) {
                            int resourceId = getResourceIdFromWeapon(T.equippedWeapon.name);
                            if (resourceId != -1) {
                                releaseResource(T.id, 1, resourceId);
                            }
                        }
                        T.hasEquippedWeapon = 0;
                        memset(&T.equippedWeapon, 0, sizeof(Weapon));
                    }
                    
                    snprintf(msg, sizeof(msg), "%s defeated! (%d/10)", T.name, g_st->enemiesKilled);
                    addLog(msg);
                    handleWeaponDrop(a.targetId);
                }
            }
            resetStamina(&P, 0);
            break;
        }
        case ACTION_SWAP_IN:
            if (swapInWeaponTracked(&P, a.weaponIndex, g_st)) {
                snprintf(msg, sizeof(msg), "%s swapped in weapon from storage!", P.name);
                addLog(msg);
                for (int s = 0; s < INVENTORY_SIZE; s++) {
                    if (P.inventory[s].isArtifact) {
                        int rid = getResourceIdFromWeapon(P.inventory[s].name);
                        if (rid != -1 && !P.holding[rid]) {
                            acquireResource(a.entityId, 0, rid);
                            if (rid == RESOURCE_SOLAR_CORE) P.hasSolarCore = 1;
                            if (rid == RESOURCE_LUNAR_BLADE) P.hasLunarBlade = 1;
                            if (rid == RESOURCE_ECLIPSE_RELIC) P.hasEclipseRelic = 1;
                        }
                    }
                }
            }
            resetStamina(&P, 0);
            break;
        case ACTION_PICKUP_WEAPON:
            handleWeaponPickup(a.entityId);
            resetStamina(&P, 0);
            break;
        case ACTION_ENEMY_PICKUP:
            handleEnemyPickupWeapon();
            break;
        case ACTION_HEAL: {
            int h = P.maxHp / 10; 
            if (h < 1) 
             h = 1;
            P.hp += h; 
            if (P.hp > P.maxHp) 
              P.hp = P.maxHp;
            snprintf(msg, sizeof(msg), "%s heals for %d HP!", P.name, h);
            addLog(msg);
            resetStamina(&P, 0);
            break;
        }
        case ACTION_SKIP:
            snprintf(msg, sizeof(msg), "%s skips.", P.name); 
            addLog(msg);
            resetStamina(&P, P.maxStamina / 2);
            break;
        default:
            resetStamina(&P, P.maxStamina / 2);
        }
    } else {
        Entity& E = g_st->enemies[a.entityId];
        int damageDealt = E.damage;
        
        if (a.actionType == ACTION_ATTACK_STRIKE &&
            a.targetId >= 0 && a.targetId < g_st->numPlayers && g_st->players[a.targetId].isAlive) {
            Entity& T = g_st->players[a.targetId];
            startAttackAnimation(1, a.entityId, 0, a.targetId);
            T.hp -= damageDealt;
            addDamageFlash(a.targetId, 0, damageDealt);
            
            if (E.hasEquippedWeapon) {
                snprintf(msg, sizeof(msg), "%s attacks %s with %s for %d damage!", 
                         E.name, T.name, E.equippedWeapon.name, damageDealt);
            } else {
                snprintf(msg, sizeof(msg), "%s attacks %s for %d damage!", 
                         E.name, T.name, damageDealt);
            }
            addLog(msg);
            
            if (rand() % 100 < 10) {
                pthread_mutex_lock(&g_flagMutex);
                int stunAlreadyActive = g_stunTimerActive;
                pthread_mutex_unlock(&g_flagMutex);
                if (g_hipPid > 0 && !stunAlreadyActive) {
                    T.isStunned = 1;
                    T.stunEndTime = time(nullptr) + 3;

                    g_st->stunnedPlayer = T.id;
                    pid_t targetHip = g_hipPid;
                    if (g_st->multiplayerMode && g_st->playerOwner[T.id] == 1 && g_hip2Pid > 0)
                        targetHip = g_hip2Pid;
                    kill(targetHip, SIGUSR1);
                    char stunMsg[64];
                    snprintf(stunMsg, sizeof(stunMsg), "%s is STUNNED for 3 seconds!", T.name);
                    addLog(stunMsg);

                    pthread_mutex_lock(&g_flagMutex);
                    g_stunTimerActive = 1;
                    g_stunDeadline = time(nullptr) + 3;
                    pthread_mutex_unlock(&g_flagMutex);
                    rearmTimer();

                    if (g_st->currentTurnOwner == 0 && g_st->currentEntityId == T.id) {
                        resetStamina(&T, 0);
                    }
                }
            }
            
            if (T.hp <= 0) {
                T.isAlive = 0;
                char deathMsg[64];
                snprintf(deathMsg, sizeof(deathMsg), "%s has fallen!", T.name);
                addLog(deathMsg);
                if (T.hasSolarCore)    
                { 
                 T.hasSolarCore = 0; 
                 releaseResource(T.id, 0, RESOURCE_SOLAR_CORE); 
                }
                if (T.hasLunarBlade) { 
                 T.hasLunarBlade = 0; 
                 releaseResource(T.id, 0, RESOURCE_LUNAR_BLADE); 
                }
                if (T.hasEclipseRelic) { 
                 T.hasEclipseRelic = 0; 
                 releaseResource(T.id, 0, RESOURCE_ECLIPSE_RELIC); 
                }
            }
        }
        resetStamina(&E, 0);
    }
    g_st->totalTurns++;
}

/* Spawn Eclipse Relic when 5 enemies are killed */
void spawnEclipseRelic() {
    if (eclipseRelicEventDone) {
        return;
    }
    
    eclipseRelicEventDone = 1;
    g_st->eclipseRelicSpawned = 1;
    
    Weapon relicWeapon;
    memset(&relicWeapon, 0, sizeof(Weapon));
    strncpy(relicWeapon.name, "Eclipse Relic", 31);
    relicWeapon.slotSize = 5;
    relicWeapon.damage = 75;
    relicWeapon.id = 8;
    relicWeapon.isArtifact = 1;

    g_st->currentDrop.weapon = relicWeapon;
    g_st->currentDrop.isAvailable = 1;
    g_st->currentDrop.enemyId = -1;
    g_st->hasWeaponDrop = 1;
    g_st->eclipseRelicOnGround = 1;
    
    g_weaponDropSprite.setPosition(640, 360);
    g_weaponDropSprite.setScale(0.6f, 0.6f);
    int texIdx = getWeaponTextureIndex("Eclipse Relic");
    g_weaponDropSprite.setTexture(g_weaponTextures[texIdx]);
    
    pthread_mutex_lock(&g_uiMutex);
    g_showWeaponDialog = 1;
    g_weaponDialogSelection = 0;
    pthread_mutex_unlock(&g_uiMutex);

    addLog("*** ECLIPSE RELIC appeared in the arena! ***");
    printf("\n*** ECLIPSE RELIC has appeared! Pick it up! ***\n");
    fflush(stdout);
}

/* Check win/loss conditions and spawn new wave if needed */
void checkGameOver() {
    int allDead = 1;
    for (int i = 0; i < g_st->numPlayers; i++)
        if (g_st->players[i].isAlive) { allDead = 0; break; }
    if (allDead) {
        addLog("GAME OVER! All players defeated.");
        g_st->gameRunning = 0; g_st->gameWinner = 0;
        sem_post(&g_st->globalTurnSem);
        return;
    }
    if (g_st->enemiesKilled >= 10) {
        addLog("VICTORY! 10 enemies defeated!");
        g_st->gameRunning = 0; g_st->gameWinner = 1;
        sem_post(&g_st->globalTurnSem);
        return;
    }
    
    if (!eclipseRelicEventDone && g_st->enemiesKilled >= 5) {
        int hasRelic = 0;
        for (int i = 0; i < g_st->numPlayers; i++) {
            if (g_st->players[i].hasEclipseRelic) {
                hasRelic = 1;
                eclipseRelicEventDone = 1;
                break;
            }
        }
        if (!hasRelic) {
            spawnEclipseRelic();
        } else {
            eclipseRelicEventDone = 1;
        }
    }
    
    int allEDead = 1;
    for (int i = 0; i < g_st->numEnemies; i++)
        if (g_st->enemies[i].isAlive) { allEDead = 0; break; }
    if (allEDead) spawnEnemyWave();
}


// SCHEDULING FUNCTIONS


//Stamina based turn scheduling system
/* Calculate time needed for entity to reach full stamina */
double getTimeToFull(Entity* e) {
    if (!e->isAlive) return 1e9;
    if (e->isStunned) return 1e9;
    if (e->speed <= 0) return 1e9;
    
    double remaining = e->maxStamina - e->currentStamina;
    if (remaining <= 0.001) 
     return 0;
    return remaining / e->speed;
}

/* Select next entity to act based on stamina accumulation */
int selectNextEntity(GameState* state) {
    double minTime = 1e9;
    int selected = -1;
    
    for (int i = 0; i < state->numPlayers; i++) {
        Entity* e = &state->players[i];
        double timeToFull = getTimeToFull(e);
        
        if (timeToFull < minTime) {
            minTime = timeToFull;
            selected = i;
        }
    }
    
    for (int i = 0; i < state->numEnemies; i++) {
        Entity* e = &state->enemies[i];
        double timeToFull = getTimeToFull(e);
        
        if (timeToFull < minTime) {
            minTime = timeToFull;
            selected = 1000 + i;
        }
    }
    
    return selected;
}

/* Advance stamina for all entities by delta time */
void advanceAllStamina(GameState* state, double delta) {
    if (delta <= 0) return;
    
    for (int i = 0; i < state->numPlayers; i++) {
        Entity* e = &state->players[i];
        if (!e->isAlive) continue;
        if (e->isStunned) continue;
        
        e->staminaAccum += (float)(e->speed * delta);
        if (e->staminaAccum > (float)e->maxStamina) {
            e->staminaAccum = (float)e->maxStamina;
        }
        e->currentStamina = (int)e->staminaAccum;
    }
    
    for (int i = 0; i < state->numEnemies; i++) {
        Entity* e = &state->enemies[i];
        if (!e->isAlive) continue;
        if (e->isStunned) continue;
        
        e->staminaAccum += (float)(e->speed * delta);
        if (e->staminaAccum > (float)e->maxStamina) {
            e->staminaAccum = (float)e->maxStamina;
        }
        e->currentStamina = (int)e->staminaAccum;
    }
}

/* Check and clear expired stuns */
void checkStunExpiry() {
    time_t now = time(nullptr);
    for (int i = 0; i < g_st->numPlayers; i++) {
        if (g_st->players[i].isStunned && now >= g_st->players[i].stunEndTime) {
            g_st->players[i].isStunned = 0;
            char msg[64];
            snprintf(msg, sizeof(msg), "%s recovered from stun!", g_st->players[i].name);
            addLog(msg);
        }
    }
}

/* Main scheduler thread selects next entity and waits for action */
void* schedulerThread(void*) {
    pthread_mutex_lock(&g_st->stateMutex);
    for (int i = 0; i < g_st->numPlayers; i++) {
        g_st->players[i].currentStamina = 0;
        g_st->players[i].staminaAccum   = 0.0f;
    }
    for (int i = 0; i < g_st->numEnemies; i++) {
        g_st->enemies[i].currentStamina = 0;
        g_st->enemies[i].staminaAccum   = 0.0f;
    }
    pthread_mutex_unlock(&g_st->stateMutex);
    
    while (g_running && g_st->gameRunning) {
        
        pthread_mutex_lock(&g_st->stateMutex);
        
        checkStunExpiry();
        
        int selected = selectNextEntity(g_st);
        
        if (selected < 0) {
            pthread_mutex_unlock(&g_st->stateMutex);
            usleep(1000);
            continue;
        }
        
        int owner, entityId;
        if (selected >= 1000) {
            owner = 1;
            entityId = selected - 1000;
        } else {
            owner = 0;
            entityId = selected;
        }
        
        Entity* entity;
        if (owner == 0) {
            entity = &g_st->players[entityId];
        } else {
            entity = &g_st->enemies[entityId];
        }
        
        if (!entity->isAlive || entity->isStunned) {
            pthread_mutex_unlock(&g_st->stateMutex);
            continue;
        }
        
        double remainingStamina = entity->maxStamina - entity->currentStamina;
        double timeNeeded = remainingStamina / entity->speed;
        
        if (timeNeeded > 0) {
            advanceAllStamina(g_st, timeNeeded);
        }
        
        entity->currentStamina = entity->maxStamina;
        entity->staminaAccum = (float)entity->maxStamina;
        
        g_st->currentTurnOwner = owner;
        g_st->currentEntityId = entityId;
        g_st->pendingAction.isReady = 0;
        g_st->guiWaitingForInput = (owner == 0) ? 1 : 0;
        g_st->guiSelectedAction = -1;
        g_st->turnStartTime = time(nullptr);

        if (owner == 0 && entityId < g_st->numPlayers &&
            g_st->players[entityId].isStunned) {
            resetStamina(&g_st->players[entityId], 0);
            char smsg[64];
            snprintf(smsg, sizeof(smsg), "%s is stunned — turn skipped!",g_st->players[entityId].name);
            addLog(smsg);
            g_st->guiWaitingForInput = 0;
            pthread_mutex_unlock(&g_st->stateMutex);
            checkGameOver();
            usleep(10000);
            continue;
        }

        pthread_mutex_unlock(&g_st->stateMutex);

        if (owner == 0) {
            sem_post(&g_st->hipActionSem);
        } else {
            sem_post(&g_st->aspActionSem);
        }
        
        int gotAction = -1;
        int totalWaitSecs = (owner == 0) ? 60 : 3;
        for (int waited = 0; waited < totalWaitSecs; waited++) {
            struct timespec ts;
            clock_gettime(CLOCK_REALTIME, &ts);
            ts.tv_sec += 1;
            gotAction = sem_timedwait(&g_st->arbiterSemaphore, &ts);
            if (gotAction == 0) break;
            pthread_mutex_lock(&g_flagMutex);
            int sf = g_stun_ended_flag;
            int uf = g_ultimate_ended_flag;
            pthread_mutex_unlock(&g_flagMutex);
            if (sf) break;
            if (uf) break;
        }

        pthread_mutex_lock(&g_flagMutex);
        int stun_ended   = g_stun_ended_flag;
        int ultimate_ended = g_ultimate_ended_flag;
        pthread_mutex_unlock(&g_flagMutex);

        if (stun_ended) {
            pthread_mutex_lock(&g_flagMutex);
            g_stun_ended_flag = 0;
            pthread_mutex_unlock(&g_flagMutex);
            {
                pid_t targetHip = g_hipPid;
                if (g_st->multiplayerMode && g_st->stunnedPlayer >= 0 &&
                    g_st->playerOwner[g_st->stunnedPlayer] == 1 && g_hip2Pid > 0)
                    targetHip = g_hip2Pid;
                if (targetHip > 0) kill(targetHip, SIGCONT);
            }
            pthread_mutex_lock(&g_st->stateMutex);
            time_t now2 = time(nullptr);
            for (int i = 0; i < g_st->numPlayers; i++) {
                if (g_st->players[i].isStunned && now2 >= g_st->players[i].stunEndTime) {
                    g_st->players[i].isStunned = 0;
                    char smsg[64];
                    snprintf(smsg, sizeof(smsg), "%s recovered from stun!", g_st->players[i].name);
                    addLog(smsg);
                }
            }
            g_st->stunnedPlayer = -1;
            pthread_mutex_unlock(&g_st->stateMutex);
            addLog("Stun ended. Player resumed.");
        }
        if (ultimate_ended) {
            pthread_mutex_lock(&g_flagMutex);
            g_ultimate_ended_flag = 0;
            g_ultimateTimerActive = 0;
            pthread_mutex_unlock(&g_flagMutex);
            if (g_aspPid > 0)
              kill(g_aspPid, SIGCONT);
            addLog("Ultimate window ended. ASP resumed.");
            sem_post(&g_st->aspActionSem);
        }

        pthread_mutex_lock(&g_st->stateMutex);

        if (gotAction == 0 && g_st->pendingAction.isReady) {
            PendingAction a = g_st->pendingAction;
            g_st->pendingAction.isReady = 0;
            g_st->guiWaitingForInput = 0;
            g_st->turnInProgress = 1;
            pthread_mutex_unlock(&g_st->stateMutex);
            executeAction(a);
            pthread_mutex_lock(&g_st->stateMutex);
            g_st->turnInProgress = 0;
            pthread_mutex_unlock(&g_st->stateMutex);
            sem_post(&g_st->globalTurnSem);
        } else {
            if (owner == 0 && entityId < g_st->numPlayers) {
                bool wasStunned = g_st->players[entityId].isStunned;
                resetStamina(&g_st->players[entityId], wasStunned ? 0 : g_st->players[entityId].maxStamina / 2);
                char msg[64];
                snprintf(msg, sizeof(msg),
                         wasStunned ? "%s turn skipped (stunned)!" : "%s timed out - skipping!",
                         g_st->players[entityId].name);
                addLog(msg);
            } else if (owner == 1 && entityId < g_st->numEnemies) {
                resetStamina(&g_st->enemies[entityId], g_st->enemies[entityId].maxStamina / 2);
                char msg[64];
                snprintf(msg, sizeof(msg), "%s timed out - skipping!", g_st->enemies[entityId].name);
                addLog(msg);
            }
            g_st->guiWaitingForInput = 0;
            pthread_mutex_unlock(&g_st->stateMutex);
            sem_post(&g_st->globalTurnSem);
        }
        
        checkGameOver();

        usleep(10000);
    }
    
    return nullptr;
}


 //RENDERING FUNCTIONS SFML graphics for game visualization


/* Load all sprite textures */
bool loadSprites() {
    std::string basePath = "sprites/";
    
    if (!g_backgroundTex.loadFromFile(basePath + "background.png")) {
        sf::Image img;
        img.create(1280, 720, sf::Color(15, 15, 35));
        g_backgroundTex.loadFromImage(img);
    }
    g_backgroundSprite.setTexture(g_backgroundTex);
    g_backgroundSprite.setScale(1280.0f / g_backgroundTex.getSize().x, 720.0f / g_backgroundTex.getSize().y);
    
    const char* playerFiles[] = {"player1.png", "player2.png", "player3.png", "player4.png"};
    sf::Color playerColors[] = {sf::Color(50, 100, 200), sf::Color(50, 200, 100), 
                                 sf::Color(200, 100, 50), sf::Color(150, 50, 200)};
    
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (!g_playerTex[i].loadFromFile(basePath + playerFiles[i])) {
            sf::Image img;
            img.create(48, 48, playerColors[i]);
            g_playerTex[i].loadFromImage(img);
        }
    }
    
    const char* enemyFiles[] = {"enemy1.png", "enemy2.png", "enemy3.png", "enemy4.png",
                                 "enemy5.png", "enemy6.png", "enemy7.png", "enemy8.png", "enemy9.png"};
    sf::Color enemyColors[] = {sf::Color(200, 50, 50), sf::Color(200, 100, 50), sf::Color(200, 50, 100),
                                sf::Color(150, 50, 50), sf::Color(180, 80, 50), sf::Color(220, 60, 60),
                                sf::Color(170, 70, 40), sf::Color(190, 55, 55), sf::Color(210, 65, 45)};
    
    for (int i = 0; i < MAX_ENEMIES; i++) {
        if (!g_enemyTex[i].loadFromFile(basePath + enemyFiles[i])) {
            sf::Image img;
            img.create(48, 48, enemyColors[i]);
            g_enemyTex[i].loadFromImage(img);
        }
    }
    
    if (!g_stunTex.loadFromFile(basePath + "stun_effect.png")) {
        sf::Image img;
        img.create(64, 64, sf::Color(255, 255, 100, 80));
        g_stunTex.loadFromImage(img);
    }
    
    const char* weaponFiles[] = {"weapon_solar.png", "weapon_lunar.png", "weapon_halberd.png",
                                  "weapon_dagger.png", "weapon_staff.png", "weapon_axe.png",
                                  "weapon_bow.png", "weapon_stick.png", "weapon_relic.png"};
    sf::Color weaponColors[] = {sf::Color(255, 200, 50), sf::Color(200, 150, 255), sf::Color(150, 150, 150),
                                 sf::Color(100, 200, 100), sf::Color(150, 100, 255), sf::Color(100, 100, 100),
                                 sf::Color(100, 200, 255), sf::Color(139, 69, 19), sf::Color(100, 50, 150)};
    
    for (int i = 0; i < 9; i++) {
        if (!g_weaponTextures[i].loadFromFile(basePath + weaponFiles[i])) {
            sf::Image img;
            img.create(32, 32, weaponColors[i]);
            g_weaponTextures[i].loadFromImage(img);
        }
    }
    
    for (int i = 0; i < MAX_PLAYERS; i++) {
        g_playerSprites[i].setTexture(g_playerTex[i]);
        g_playerSprites[i].setScale(0.8f, 0.8f);
        g_playerSprites[i].setPosition(55, 75 + i * 110);
        g_stunOverlay[i].setTexture(g_stunTex);
        g_stunOverlay[i].setScale(0.8f, 0.8f);
        g_stunOverlay[i].setPosition(55, 75 + i * 110);
    }
    
    for (int i = 0; i < MAX_ENEMIES; i++) {
        g_enemySprites[i].setTexture(g_enemyTex[i]);
        g_enemySprites[i].setScale(0.7f, 0.7f);
        int cols = 3;
        int row = i / cols;
        int col = i % cols;
        g_enemySprites[i].setPosition(790 + col * 95, 80 + row * 100);
    }
    
    return true;
}

/* Draw text on window */
void drawText(sf::RenderWindow& w, const std::string& s, float x, float y, unsigned sz, sf::Color c) {
    if (!g_fontLoaded) return;
    sf::Text t; t.setFont(g_font); t.setString(s);
    t.setCharacterSize(sz); t.setFillColor(c); t.setPosition(x, y);
    w.draw(t);
}

/* Draw health/stamina bar */
void drawBar(sf::RenderWindow& w, float x, float y, float W, float H, float pct, sf::Color bg, sf::Color fg) {
    if (pct < 0) pct = 0; 
    if (pct > 1) pct = 1;
    sf::RectangleShape b({W,H}); b.setPosition(x,y); b.setFillColor(bg); w.draw(b);
    sf::RectangleShape f({W*pct,H}); f.setPosition(x,y); f.setFillColor(fg); w.draw(f);
}

/* Main render thread draws game UI using SFML */
void* renderThread(void*) {
    sf::RenderWindow win({1280, 720}, "Chrono Rift - Turn Based Combat");
    win.setFramerateLimit(60);
    
    const char* fonts[] = {
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-R.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        nullptr
    };
    for (int i = 0; fonts[i]; i++)
        if (g_font.loadFromFile(fonts[i])) { g_fontLoaded = true; break; }
    
    loadSprites();
    
    bool showInventoryMenu = false;
    int selectedEnemyForAttack = -1;
    float pulseTime = 0;
    sf::Clock clock;
    int inventoryViewingPlayer = -1;
    
    struct AttackAnimation {
        int active;
        int attackerType;
        int attackerId;
        int targetType;
        int targetId;
        float startX, startY;
        float targetX, targetY;
        float progress;
    };
    AttackAnimation attackAnim = {0, -1, -1, -1, -1, 0, 0, 0, 0, 0};
    
    while (win.isOpen() && g_running) {
        float deltaTime = clock.restart().asSeconds();
        
        sf::Event ev;
        while (win.pollEvent(ev)) {
            if (ev.type == sf::Event::Closed) {
                win.close();
                g_running = 0;
                g_st->gameRunning = 0;
            }
        }
        
        win.clear(sf::Color(15, 15, 35));
        
        pthread_mutex_lock(&g_st->stateMutex);
        
        int enemiesKilled = g_st->enemiesKilled;
        int totalTurns = g_st->totalTurns;
        int gameRunning = g_st->gameRunning;
        int gameWinner = g_st->gameWinner;
        int currentTurnOwner = g_st->currentTurnOwner;
        int currentEntityId = g_st->currentEntityId;
        int guiWaitingForInput = g_st->guiWaitingForInput;
        int guiSelectedAction = g_st->guiSelectedAction;
        int numPlayers = g_st->numPlayers;
        int numEnemies = g_st->numEnemies;
        
        Entity playersCopy[MAX_PLAYERS];
        for (int i = 0; i < numPlayers; i++) {
            playersCopy[i] = g_st->players[i];
        }
        
        Entity enemiesCopy[MAX_ENEMIES];
        for (int i = 0; i < numEnemies; i++) {
            enemiesCopy[i] = g_st->enemies[i];
        }
        
        ActionLogEntry actionLogCopy[MAX_ACTION_LOG];
        int actionLogCount = g_st->actionLogCount;
        int actionLogHead = g_st->actionLogHead;
        for (int i = 0; i < actionLogCount && i < MAX_ACTION_LOG; i++) {
            int idx = (actionLogHead + i) % MAX_ACTION_LOG;
            actionLogCopy[i] = g_st->actionLog[idx];
        }
        
        pthread_mutex_unlock(&g_st->stateMutex);
        
        pthread_mutex_lock(&g_st->stateMutex);
        int hasDrop = g_st->hasWeaponDrop;
        int dropAvailable = g_st->currentDrop.isAvailable;
        int eclipseOnGround = g_st->eclipseRelicOnGround;
        Weapon currentWeapon = g_st->currentDrop.weapon;
        pthread_mutex_unlock(&g_st->stateMutex);

        pthread_mutex_lock(&g_uiMutex);
        int showDialog = g_showWeaponDialog;
        int weaponAnim = g_weaponAnimating;
        int animTarget = g_weaponAnimTarget;
        float animX = g_weaponAnimX;
        float animY = g_weaponAnimY;
        if (g_attackAnimRequest && !attackAnim.active) {
            attackAnim.active = 1;
            attackAnim.attackerType = g_attackAnimAttackerType;
            attackAnim.attackerId = g_attackAnimAttackerId;
            attackAnim.targetType = g_attackAnimTargetType;
            attackAnim.targetId = g_attackAnimTargetId;
            attackAnim.progress = 0;
            attackAnim.startX = (attackAnim.attackerType == 0) ? 58 : 790;
            attackAnim.startY = (attackAnim.attackerType == 0) ? 115 + attackAnim.attackerId * 110 : 115 + attackAnim.attackerId * 65;
            attackAnim.targetX = (attackAnim.targetType == 0) ? 58 : 790;
            attackAnim.targetY = (attackAnim.targetType == 0) ? 115 + attackAnim.targetId * 110 : 115 + attackAnim.targetId * 65;
            g_attackAnimRequest = 0;
            g_attackAnimDone = 0;
        }
        pthread_mutex_unlock(&g_uiMutex);
        
        if (!attackAnim.active) {
            updateDamageFlashes(deltaTime);
            pulseTime += deltaTime;
        }
        
        if (attackAnim.active) {
            attackAnim.progress += deltaTime * 2.4f;
            if (attackAnim.progress >= 1.0f) {
                attackAnim.active = 0;
                pthread_mutex_lock(&g_uiMutex);
                g_attackAnimDone = 1;
                pthread_mutex_unlock(&g_uiMutex);
            }
        }
        
        win.draw(g_backgroundSprite);
        
        sf::RectangleShape headerBar({1280, 45});
        headerBar.setPosition(0, 0);
        headerBar.setFillColor(sf::Color(0, 0, 0, 220));
        win.draw(headerBar);
        drawText(win, "CHRONO RIFT", 540, 8, 28, {220, 180, 60});
        
        sf::RectangleShape statsBar({420, 30});
        statsBar.setPosition(430, 50);
        statsBar.setFillColor(sf::Color(0, 0, 0, 200));
        statsBar.setOutlineColor(sf::Color(100, 80, 60));
        statsBar.setOutlineThickness(1);
        win.draw(statsBar);
        
        char killsText[64];
        snprintf(killsText, sizeof(killsText), "ENEMIES KILLED: %d / 10", enemiesKilled);
        drawText(win, killsText, 440, 55, 14, {255, 200, 100});
        
        char turnsText[64];
        snprintf(turnsText, sizeof(turnsText), "TOTAL TURNS: %d", totalTurns);
        drawText(win, turnsText, 680, 55, 14, {150, 200, 255});
        
        drawText(win, "PLAYERS", 60, 85, 18, {100, 200, 255});
        drawText(win, "ENEMIES", 790, 85, 18, {255, 100, 100});
        
        for (int i = 0; i < numPlayers; i++) {
            Entity& p = playersCopy[i];
            float y = 115 + i * 110;
            float shakeX = getShakeOffset(i, 0);
            int damageNum = getDamageNumber(i, 0);
            float damageTimer = getDamageTimer(i, 0);
            
            if (currentTurnOwner == 0 && currentEntityId == i && gameRunning && !showDialog) {
                sf::RectangleShape border(sf::Vector2f(310, 60));
                border.setPosition(55 + shakeX, y - 5);
                border.setFillColor(sf::Color::Transparent);
                border.setOutlineColor(sf::Color::Yellow);
                border.setOutlineThickness(3);
                win.draw(border);
            }
            
            g_playerSprites[i].setPosition(58 + shakeX, y);
            if (!(attackAnim.active && attackAnim.attackerType == 0 && attackAnim.attackerId == i)) {
                win.draw(g_playerSprites[i]);
            }
            
            char info[80];
            snprintf(info, sizeof(info), "%s  DMG:%d", p.name, p.damage);
            drawText(win, info, 120 + shakeX, y - 20, 13, p.isAlive ? sf::Color::White : sf::Color(120, 120, 120));
            
            float hp = p.maxHp > 0 ? (float)p.hp / p.maxHp : 0;
            sf::Color hc = hp > 0.5f ? sf::Color{50, 200, 50} : hp > 0.25f ? sf::Color{220, 180, 0} : sf::Color{220, 50, 50};
            drawBar(win, 120 + shakeX, y, 250, 18, hp, {60, 20, 20}, hc);
            drawBar(win, 120 + shakeX, y + 22, 250, 10, p.maxStamina > 0 ? (float)p.currentStamina / p.maxStamina : 0, {20, 20, 60}, {0, 150, 255});
            
            char hpText[32];
            snprintf(hpText, sizeof(hpText), "%d/%d", p.hp, p.maxHp);
            drawText(win, hpText, 220 + shakeX, y + 4, 12, sf::Color::Black);
            
            char stamText[32];
            snprintf(stamText, sizeof(stamText), "%d/%d", p.currentStamina, p.maxStamina);
            drawText(win, stamText, 380 + shakeX, y + 24, 10, {150, 200, 255});
            
            if (damageNum > 0 && damageTimer > 0) {
                char dmgText[16];
                snprintf(dmgText, sizeof(dmgText), "-%d", damageNum);
                drawText(win, dmgText, 130 + shakeX, y + 4, 16, sf::Color(255, 255, 100, 220));
            }
            
            if (p.isStunned) {
                sf::RectangleShape stunOverlay({300, 55});
                stunOverlay.setPosition(120 + shakeX, y);
                stunOverlay.setFillColor(sf::Color(255, 255, 100, 80));
                win.draw(stunOverlay);
                drawText(win, "STUNNED", 240 + shakeX, y + 15, 14, {255, 200, 0});
            }
            
            if (currentTurnOwner == 0 && currentEntityId == i && gameRunning) {
                sf::CircleShape d(10);
                d.setPosition(22 + shakeX, y + 6);
                d.setFillColor(sf::Color::Yellow);
                win.draw(d);
            }
            
            if (!p.isAlive) {
                sf::RectangleShape ov({300, 50});
                ov.setPosition(120 + shakeX, y);
                ov.setFillColor({0, 0, 0, 180});
                win.draw(ov);
                drawText(win, "DEFEATED", 240 + shakeX, y + 15, 14, {180, 50, 50});
            }
        }
        
        int maxEnemies = numEnemies;
        for (int i = 0; i < maxEnemies; i++) {
            Entity& e = enemiesCopy[i];
            if (!e.isAlive) continue;
            
            float x = 790;
            float y = 115 + i * 65;
            float shakeX = getShakeOffset(i, 1);
            int damageNum = getDamageNumber(i, 1);
            float damageTimer = getDamageTimer(i, 1);
            
            sf::RectangleShape enemyRect(sf::Vector2f(340, 55));
            enemyRect.setPosition(x - 5 + shakeX, y - 8);
            enemyRect.setFillColor(sf::Color::Transparent);
            enemyRect.setOutlineColor(sf::Color(255, 255, 100));
            enemyRect.setOutlineThickness(2);
            win.draw(enemyRect);
            
            if (selectedEnemyForAttack == i && guiSelectedAction >= 1 && guiSelectedAction <= 3) {
                sf::RectangleShape highlight(sf::Vector2f(340, 55));
                highlight.setPosition(x - 5 + shakeX, y - 8);
                highlight.setFillColor(sf::Color::Transparent);
                highlight.setOutlineColor(sf::Color(255, 0, 0));
                highlight.setOutlineThickness(4);
                win.draw(highlight);
            }
            
            if (currentTurnOwner == 1 && currentEntityId == i && gameRunning) {
                sf::RectangleShape border(sf::Vector2f(340, 55));
                border.setPosition(x - 5 + shakeX, y - 8);
                border.setFillColor(sf::Color::Transparent);
                border.setOutlineColor(sf::Color(255, 100, 100));
                border.setOutlineThickness(3);
                win.draw(border);
            }
            
            g_enemySprites[i].setPosition(x + shakeX, y);
            if (!(attackAnim.active && attackAnim.attackerType == 1 && attackAnim.attackerId == i)) {
                win.draw(g_enemySprites[i]);
            }
            
            char info[128];
            snprintf(info, sizeof(info), "%s", e.name);
            if (e.hasEquippedWeapon) {
                snprintf(info + strlen(info), sizeof(info) - strlen(info), " [%s]", e.equippedWeapon.name);
            }
            drawText(win, info, x + 40 + shakeX, y - 16, 11, e.isAlive ? sf::Color::White : sf::Color(120, 120, 120));
            
            float hp = e.maxHp > 0 ? (float)e.hp / e.maxHp : 0;
            drawBar(win, x + 40 + shakeX, y, 250, 12, hp, {40, 10, 10}, {180, 60, 60});
            drawBar(win, x + 40 + shakeX, y + 14, 250, 6, e.maxStamina > 0 ? (float)e.currentStamina / e.maxStamina : 0, {30, 20, 10}, {255, 160, 0});
            
            char hpText[32];
            snprintf(hpText, sizeof(hpText), "%d/%d", e.hp, e.maxHp);
            drawText(win, hpText, x + 165 + shakeX, y + 2, 10, sf::Color::Black);
            
            if (damageNum > 0 && damageTimer > 0) {
                char dmgText[16];
                snprintf(dmgText, sizeof(dmgText), "-%d", damageNum);
                drawText(win, dmgText, x + 50 + shakeX, y + 2, 14, sf::Color(255, 255, 100, 220));
            }
            
            if (currentTurnOwner == 1 && currentEntityId == i && gameRunning) {
                sf::CircleShape d(6);
                d.setPosition(x + 20 + shakeX, y + 15);
                d.setFillColor(sf::Color::Yellow);
                win.draw(d);
            }
            
            if (guiSelectedAction >= 1 && guiSelectedAction <= 3 && guiWaitingForInput == 1) {
                int numAlive = 0;
                int aliveIdx = -1;
                for (int j = 0; j < maxEnemies; j++) {
                    if (enemiesCopy[j].isAlive) {
                        if (j == i) aliveIdx = numAlive;
                        numAlive++;
                    }
                }
                if (aliveIdx >= 0) {
                    char numStr[4];
                    snprintf(numStr, sizeof(numStr), "%d", aliveIdx + 1);
                    drawText(win, numStr, x + 10 + shakeX, y - 20, 16, 
                            (selectedEnemyForAttack == i) ? sf::Color::Yellow : sf::Color(200, 200, 200));
                }
            }
        }
        
        if (attackAnim.active) {
            float phase = attackAnim.progress < 0.5f ? attackAnim.progress * 2 : (1.0f - attackAnim.progress) * 2;
            float curX = attackAnim.startX + (attackAnim.targetX - attackAnim.startX) * phase;
            float curY = attackAnim.startY + (attackAnim.targetY - attackAnim.startY) * phase;
            if (attackAnim.attackerType == 0 && attackAnim.attackerId >= 0 && attackAnim.attackerId < MAX_PLAYERS) {
                g_playerSprites[attackAnim.attackerId].setPosition(curX, curY);
                win.draw(g_playerSprites[attackAnim.attackerId]);
            } else if (attackAnim.attackerType == 1 && attackAnim.attackerId >= 0 && attackAnim.attackerId < MAX_ENEMIES) {
                g_enemySprites[attackAnim.attackerId].setPosition(curX, curY);
                win.draw(g_enemySprites[attackAnim.attackerId]);
            }
        }
        
        if (hasDrop && dropAvailable && !weaponAnim && !showDialog) {
            if (!attackAnim.active) g_floatingOffset += deltaTime;
            float offset = sin(g_floatingOffset * 8) * 3;
            g_weaponDropSprite.move(0, offset);
            win.draw(g_weaponDropSprite);
            char dropMsg[128];
            if (eclipseOnGround) {
                snprintf(dropMsg, sizeof(dropMsg), "ECLIPSE RELIC: %s! (DMG:%d)", 
                         currentWeapon.name, currentWeapon.damage);
                drawText(win, dropMsg, 380, 680, 14, {200, 100, 255});
            } else {
                snprintf(dropMsg, sizeof(dropMsg), "WEAPON DROP: %s! (DMG:%d)", 
                         currentWeapon.name, currentWeapon.damage);
                drawText(win, dropMsg, 380, 680, 14, {255, 200, 0});
            }
        }
        
        if (weaponAnim) {
            pthread_mutex_lock(&g_uiMutex);
            int step = g_weaponAnimStep;
            int target = g_weaponAnimTarget;
            float x = g_weaponAnimX;
            float y = g_weaponAnimY;
            pthread_mutex_unlock(&g_uiMutex);
            
            if (step < 15) {
                float progress = step / 15.0f;
                float targetX = 58 + 35;
                float targetY = 115 + target * 110 + 35;
                float newX = x + (targetX - x) * progress;
                float newY = y + (targetY - y) * progress;
                g_weaponDropSprite.setPosition(newX, newY);
                g_weaponDropSprite.setScale(0.5f - progress * 0.4f, 0.5f - progress * 0.4f);
                
                pthread_mutex_lock(&g_uiMutex);
                g_weaponAnimStep++;
                pthread_mutex_unlock(&g_uiMutex);
            } else {
                pthread_mutex_lock(&g_uiMutex);
                g_weaponAnimating = 0;
                g_weaponAnimStep = 0;
                pthread_mutex_unlock(&g_uiMutex);
                g_weaponDropSprite.setScale(0.5f, 0.5f);
            }
            win.draw(g_weaponDropSprite);
        }
        
        sf::RectangleShape lb({680, 155});
        lb.setPosition(50, 522);
        lb.setFillColor({10, 10, 25, 220});
        lb.setOutlineColor({80, 60, 120});
        lb.setOutlineThickness(2);
        win.draw(lb);
        drawText(win, "ACTION LOG", 56, 526, 14, {200, 180, 255});
        
        int total = actionLogCount;
        int start = total > 7 ? total - 7 : 0;
        for (int i = start; i < total; i++) {
            int idx = i;
            std::string msg = actionLogCopy[i].message;
            if (msg.length() > 70) msg = msg.substr(0, 67) + "...";
            drawText(win, msg, 58, 544 + (i - start) * 17, 11, {210, 210, 210});
        }
        
        if (gameRunning && currentTurnOwner == 0 && guiWaitingForInput == 1 && !showDialog) {
            sf::RectangleShape msgBg({400, 40});
            msgBg.setPosition(440, 620);
            msgBg.setFillColor(sf::Color(0, 0, 0, 200));
            msgBg.setOutlineColor(sf::Color(100, 200, 100));
            msgBg.setOutlineThickness(2);
            win.draw(msgBg);
            drawText(win, "Waiting for input from HIP...", 455, 628, 14, {100, 255, 100});
        }
        
        if (currentTurnOwner == 0 && currentEntityId >= 0 &&
            playersCopy[currentEntityId].hasSolarCore && 
            playersCopy[currentEntityId].hasLunarBlade) {
            drawText(win, "ULTIMATE READY! (Both Artifacts)", 58, 480, 13, {255, 100, 0});
        }

        {
            float panelX = 780.0f;
            float panelY = 500.0f;
            float panelW = 490.0f;
            float panelH = 110.0f;

            sf::RectangleShape invBg({panelW, panelH});
            invBg.setPosition(panelX, panelY);
            invBg.setFillColor(sf::Color(10, 10, 30, 210));
            invBg.setOutlineColor(sf::Color(80, 60, 130));
            invBg.setOutlineThickness(2);
            win.draw(invBg);
            drawText(win, "INVENTORY", panelX + 4, panelY + 2, 13, {200, 180, 255});

            for (int pi = 0; pi < numPlayers; pi++) {
                Entity& p = playersCopy[pi];
                float rowY = panelY + 20 + pi * 22;

                char plabel[8];
                snprintf(plabel, sizeof(plabel), "%s:", p.name);
                sf::Color labelCol = p.isAlive ? sf::Color(100, 220, 255) : sf::Color(120, 120, 120);
                drawText(win, plabel, panelX + 4, rowY, 11, labelCol);

                if (!p.isAlive) {
                    drawText(win, "[defeated]", panelX + 30, rowY, 11, {120, 120, 120});
                    continue;
                }

                char seen[INVENTORY_SIZE][32];
                int seenCount = 0;
                float wx = panelX + 34;

                for (int s = 0; s < INVENTORY_SIZE && wx < panelX + panelW - 4; s++) {
                    if (p.inventory[s].slotSize == 0) continue;
                    if (s > 0 && p.inventory[s-1].slotSize != 0 &&
                        strcmp(p.inventory[s-1].name, p.inventory[s].name) == 0) continue;

                    bool alreadySeen = false;
                    for (int k = 0; k < seenCount; k++) {
                        if (strcmp(seen[k], p.inventory[s].name) == 0) { alreadySeen = true; break; }
                    }
                    if (alreadySeen) continue;
                    if (seenCount < INVENTORY_SIZE) {
                        strncpy(seen[seenCount++], p.inventory[s].name, 31);
                    }

                    bool isArt = (p.inventory[s].isArtifact != 0);
                    sf::Color wCol = isArt ? sf::Color(255, 215, 0) : sf::Color(200, 200, 200);

                    char abbr[12];
                    strncpy(abbr, p.inventory[s].name, 8);
                    abbr[8] = '\0';
                    char wlabel[20];
                    snprintf(wlabel, sizeof(wlabel), "[%s]", abbr);

                    drawText(win, wlabel, wx, rowY, 10, wCol);
                    wx += strlen(wlabel) * 6.5f + 4;
                }

                if (seenCount == 0) {
                    drawText(win, "[empty]", panelX + 34, rowY, 10, {100, 100, 100});
                }

                if (p.longTermCount > 0) {
                    char ltText[24];
                    snprintf(ltText, sizeof(ltText), "+%dLTS", p.longTermCount);
                    drawText(win, ltText, panelX + panelW - 44, rowY, 10, {180, 150, 255});
                }
            }

            pthread_mutex_lock(&g_st->stateMutex);
            int fragCount = g_st->totalFragments;
            int allocCount = g_st->allocationCount;
            int compactCount = g_st->compactionCount;
            pthread_mutex_unlock(&g_st->stateMutex);

            char memStats[80];
            snprintf(memStats, sizeof(memStats), "Allocs:%d  Frags:%d  Compacts:%d",
                     allocCount, fragCount, compactCount);
            drawText(win, memStats, panelX + 4, panelY + panelH - 16, 10, {150, 150, 200});
        }
        
        if (!gameRunning) {
            sf::RectangleShape ov({1280, 720});
            ov.setFillColor({0, 0, 0, 200});
            win.draw(ov);
            if (gameWinner == 1) {
                drawText(win, "VICTORY!", 550, 290, 48, {80, 255, 80});
                drawText(win, "You defeated all 10 enemies!", 510, 360, 18, {200, 200, 200});
            } else {
                drawText(win, "GAME OVER", 520, 290, 48, {255, 80, 80});
                drawText(win, "All players have fallen...", 510, 360, 18, {200, 200, 200});
            }
            drawText(win, "Closing in 3 seconds...", 540, 420, 16, {180, 180, 180});
            win.display();
            sf::sleep(sf::seconds(3));
            win.close();
            break;
        }
        
        win.display();
        sf::sleep(sf::milliseconds(16));
    }
    
    g_running = 0;
    g_st->gameRunning = 0;
    return nullptr;
}

//Main
int main() {
    {
        int dn = open("/dev/null", O_WRONLY);
        if (dn != -1) { dup2(dn, STDERR_FILENO); close(dn); }
    }

    signal(SIGTERM, onSIGTERM);
    signal(SIGALRM, onSIGALRM);
    signal(SIGCHLD, SIG_DFL);
    signal(SIGPIPE, SIG_IGN);

    printf("========================================\n");
    printf("CHRONO RIFT\n");
    printf("========================================\n");
    
    eclipseRelicEventDone = 0;
    g_relicSpawned = 0;
    int rollNumber;
    g_eclipseRelicSpawnAttempted = 0;
    
    printf("Enter roll number: "); 
    fflush(stdout);
    scanf("%d", &rollNumber);
    g_rollNumber = rollNumber;
    srand(rollNumber);

    int numPlayers;
    printf("Party size (1-4): "); 
    fflush(stdout);
    scanf("%d", &numPlayers);
    if (numPlayers < 1) numPlayers = 1;
    if (numPlayers > 4) numPlayers = 4;

    int multiplayerMode = 0;
    if (numPlayers >= 2) {
        printf("Enable local multiplayer? (2 terminals, first %d players on this terminal, rest on second) [y/n]: ", numPlayers / 2);
        fflush(stdout);
        char mpChoice[8] = {0};
        scanf("%s", mpChoice);
        if (mpChoice[0] == 'y' || mpChoice[0] == 'Y') multiplayerMode = 1;
    }

    try {
        g_shm = new SharedMemoryManager(SHM_NAME, 1);
    } catch (const char* e) {
        fprintf(stderr, "ARBITER: shm create failed: %s\n", e);
        return 1;
    }
    g_st = g_shm->getState();
    g_st->eclipseRelicOffered = 0;

    pthread_mutex_lock(&g_st->stateMutex);

    memset(g_st->players, 0, sizeof(g_st->players));
    memset(g_st->enemies, 0, sizeof(g_st->enemies));
    memset(&g_st->resources, 0, sizeof(g_st->resources));

    g_st->gameRunning = 1;
    g_st->gameWinner = -1;
    g_st->enemiesKilled = 0;
    g_st->totalTurns = 0;
    g_st->numPlayers = numPlayers;
    g_st->rollNumber = rollNumber;
    g_st->deadlockDetected = 0;
    g_st->deadlockVictimEntity = -1;
    g_st->deadlockVictimType = -1;
    g_st->stunnedPlayer = -1;
    g_st->turnStartTime = 0;
    g_st->totalTurnaroundTime = 0.0;
    g_st->pendingAction.isReady = 0;
    g_st->hasWeaponDrop = 0;
    g_st->currentDrop.isAvailable = 0;
    g_st->eclipseRelicSpawned = 0;
    g_st->eclipseRelicOnGround = 0;
    g_st->multiplayerMode = multiplayerMode;
    g_st->hip2Pid = 0;
    
    int splitAt = numPlayers / 2;
    if (splitAt < 1) splitAt = numPlayers;
    for (int i = 0; i < numPlayers; i++)
        g_st->playerOwner[i] = (multiplayerMode && i >= splitAt) ? 1 : 0;
    
    g_st->guiWaitingForInput = 0;
    g_st->guiSelectedAction = -1;
    g_st->guiSelectedTarget = -1;
    g_st->guiSelectedWeapon = -1;
    g_st->turnInProgress = 0;

    initResourceTable();

    for (int i = 0; i < numPlayers; i++) {
        Entity& p = g_st->players[i];
        p.id = i;
        snprintf(p.name, 32, "P%d", i+1);
        p.hp = rollNumber + 100 + (rand() % 901);
        p.maxHp = p.hp;
        p.damage = (rollNumber % 10) + 10;
        p.speed = 100 / numPlayers;
        p.maxStamina = 100;
        p.currentStamina = 0;
        p.staminaAccum  = 0.0f;
        p.isAlive = 1;
        p.isStunned = 0;
        p.hasSolarCore = 0;
        p.hasLunarBlade = 0;
        p.hasEclipseRelic = 0;
        p.inventoryUsedSlots = 0;
        p.longTermCount = 0;
        p.hasEquippedWeapon = 0;
        initEntityResources(&p);
        
        printf("  P%d: HP=%d, DMG=%d, SPD=%d (No starter weapon)\n",i+1, p.hp, p.damage, p.speed);
    }

    int lastTwo = rollNumber % 100;
    int secondLast = (rollNumber / 10) % 10;
    g_st->numEnemies = 2 + (rand() % 8);
    printf("\nEnemies spawned: %d\n", g_st->numEnemies);
    for (int i = 0; i < g_st->numEnemies; i++) {
        Entity& e = g_st->enemies[i];
        e.id = i;
        snprintf(e.name, 32, "E%d", i+1);
        e.hp = lastTwo + 50 + (rand() % 151);
        e.maxHp = e.hp;
        e.damage = secondLast + 10;
        e.speed = 10 + (rand() % 21);
        e.maxStamina = 150;
        e.currentStamina = 0;
        e.staminaAccum   = 0.0f;
        e.isAlive = 1;
        e.isStunned = 0;
        e.hasEquippedWeapon = 0;
        memset(&e.equippedWeapon, 0, sizeof(Weapon));
        initEntityResources(&e);
        printf("  %s: HP=%d, DMG=%d, SPD=%d\n", e.name, e.hp, e.damage, e.speed);
    }

    pthread_mutex_unlock(&g_st->stateMutex);

    printf("\n========================================\n");
    printf("GAME STARTED!\n");
    printf("========================================\n"); fflush(stdout);

    spawnProcess("./hips", &g_hipPid, 1);
    spawnProcess("./asps", &g_aspPid, 0);
    g_st->hipPid = g_hipPid;
    g_st->aspPid = g_aspPid;
    g_st->arbiterPid = getpid();

    if (multiplayerMode) {
        printf("\n");
        printf("╔══════════════════════════════════════════════════════════════════╗\n");
        printf("║                  *** MULTIPLAYER MODE ACTIVE ***                 ║\n");
        printf("╠══════════════════════════════════════════════════════════════════╣\n");
        printf("║  Player 1 (P1):  play on THIS terminal                           ║\n");
        printf("║                                                                  ║\n");
        printf("║  Player 2 (P%d):  open a NEW terminal and run:                   ║\n", splitAt + 1);
        printf("║                                                                  ║\n");
        printf("║    docker exec -it $(hostname) bash                              ║\n");
        printf("║    cd /app                                                       ║\n");
        printf("║    ./hips --player-start %d --player-end %d                   ║\n", splitAt, numPlayers - 1);
        printf("║                                                                  ║\n");
        printf("╚══════════════════════════════════════════════════════════════════╝\n\n");
        fflush(stdout);

        printf("  Waiting for Player 2 terminal to connect (up to 120s)...\n");
        fflush(stdout);
        int waited = 0;
        while (g_st->hip2Pid == 0 && waited < 120) {
            sleep(1);
            waited++;
            if (waited % 15 == 0) {
                printf("  Still waiting for P2... (%ds elapsed)\n", waited);
                fflush(stdout);
            }
        }
        if (g_st->hip2Pid == 0) {
            printf("  [WARNING] P2 terminal never connected. Falling back to single-HIP mode.\n\n");
            g_st->multiplayerMode = 0;
        } else {
            g_hip2Pid = g_st->hip2Pid;
            printf("  [OK] Player 2 terminal connected (PID %d). Starting game!\n\n", g_hip2Pid);
        }
        fflush(stdout);
    }

    sleep(1);

    pthread_t tScheduler, tRender, tDeadlockDetector;
    pthread_create(&tScheduler, nullptr, schedulerThread, nullptr);
    pthread_create(&tRender, nullptr, renderThread, nullptr);
    pthread_create(&tDeadlockDetector, nullptr, deadlockDetectorThread, nullptr);

    while (g_running && g_st->gameRunning) sleep(1);

    pthread_join(tRender, nullptr);

    g_running = 0;
    if (g_aspPid > 0) { 
      kill(g_aspPid, SIGCONT);  
      usleep(50000); 
     }
    if (g_hipPid > 0) { 
      kill(g_hipPid, SIGTERM); 
      waitpid(g_hipPid, nullptr, 0); 
    }
    if (g_hip2Pid > 0) { 
      kill(g_hip2Pid, SIGTERM); 
      waitpid(g_hip2Pid, nullptr, 0); 
    }
    if (g_aspPid > 0) { 
      kill(g_aspPid, SIGTERM); 
      waitpid(g_aspPid, nullptr, 0); 
     }

    pthread_cancel(tScheduler); pthread_join(tScheduler, nullptr);
    pthread_cancel(tDeadlockDetector); pthread_join(tDeadlockDetector, nullptr);

    printf("\n========================================\n");
    printf("GAME ENDED - %s\n", g_st->gameWinner == 1 ? "YOU WIN!" : "GAME OVER");
    printf("Enemies killed: %d/10\n", g_st->enemiesKilled);
    printf("Total turns: %d\n", g_st->totalTurns);
    printf("--- TURNAROUND TIME ANALYSIS ---\n");
    printf("Total action time: %.2f seconds\n", g_st->totalTurnaroundTime);
    if (g_st->totalTurns > 0)
        printf("Average turnaround per turn: %.2f seconds\n",
               g_st->totalTurnaroundTime / g_st->totalTurns);
    printf("========================================\n");

    delete g_shm;
    return 0;
}
