#ifndef WEAPONS_H
#define WEAPONS_H

#include "GameState.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>

/* Weapon db all weapons with their size, damage, and artifact status */
static const Weapon WEAPON_DB[] = {
    {"Solar Core", 10, 95, 0, 1},
    {"Lunar Blade", 10, 90, 1, 1},
    {"Iron Halberd", 7, 55, 2, 0},
    {"Venom Dagger", 4, 30, 3, 0},
    {"Thunderstaff", 6, 50, 4, 0},
    {"Obsidian Axe", 5, 45, 5, 0},
    {"Frostbow", 6, 48, 6, 0},
    {"Splinter Stick", 2, 12, 7, 0},
    {"Eclipse Relic", 5, 75, 8, 1}
};

/* Forward declarations */
static int findFreeSpace(Weapon* inventory, int slotSize);
static int swapOutWeapons(Entity* entity, int neededSlots);

/* Get remaining free slots in inventory */
static int getRemainingSlots(Entity* entity) {
    return INVENTORY_SIZE - entity->inventoryUsedSlots;
}

/* Record allocation */
static void recordAllocation(GameState* state, int startSlot, int size, const Weapon* weapon) {
    if (!state) return;
    for (int i = 0; i < MAX_ALLOCATIONS; i++) {
        if (!state->allocations[i].isActive) {
            state->allocations[i].startSlot = startSlot;
            state->allocations[i].size = size;
            state->allocations[i].weaponId = weapon->id;
            strncpy(state->allocations[i].weaponName, weapon->name, 31);
            state->allocations[i].isActive = 1;
            state->allocationCount++;
            break;
        }
    }
}

/* Calculate fragmentation means count of empty gaps between weapons */
static int calculateFragmentation(Weapon* inventory) {
    int gapCount = 0;
    int currentGap = 0;
    
    for (int i = 0; i < INVENTORY_SIZE; i++) {
        if (inventory[i].slotSize == 0) {
            currentGap++;
        } else {
            if (currentGap > 0) {
                gapCount++;
                currentGap = 0;
            }
        }
    }
    if (currentGap > 0) gapCount++;
    
    return gapCount;
}

/* Compact inventory as remove gaps by shifting weapons together */
static void compactInventory(Weapon* inventory, int* usedSlots) {
    Weapon temp[INVENTORY_SIZE];
    int tempCount = 0;
    int originalUsed = *usedSlots;
    
    printf("COMPACTING: Before compaction, used slots = %d\n", originalUsed);
    
    // Collect all weapons
    for (int i = 0; i < INVENTORY_SIZE; i++) {
        if (inventory[i].slotSize == 0) continue;
        
        bool isStart = (i == 0) ||(inventory[i-1].slotSize == 0) ||
                       (strcmp(inventory[i-1].name, inventory[i].name) != 0);
        if (isStart) {
            temp[tempCount++] = inventory[i];
        }
    }
    
    // Clear inventory
    memset(inventory, 0, sizeof(Weapon) * INVENTORY_SIZE);
    
    // Re pack contiguously
    int writePos = 0;
    for (int k = 0; k < tempCount; k++) {
        for (int j = writePos; j < writePos + temp[k].slotSize && j < INVENTORY_SIZE; j++) {
            inventory[j] = temp[k];
        }
        writePos += temp[k].slotSize;
    }
    
    *usedSlots = writePos;
    printf("COMPACTING: After compaction, used slots = %d (fragments removed)\n", *usedSlots);
}

/* Find contiguous free space using best-fit then first-fit */
static int findFreeSpace(Weapon* inventory, int slotSize) {
    int bestStart = -1;
    int bestGap = INVENTORY_SIZE + 1;
    
    // First pass is best-fit finds smallest sufficient contiguous block
    for (int i = 0; i <= INVENTORY_SIZE - slotSize; i++) {
        bool isFree = true;
        for (int j = 0; j < slotSize; j++) {
            if (inventory[i + j].slotSize != 0) {
                isFree = false;
                break;
            }
        }
        if (isFree) {
            int remainingFree = 0;
            for (int j = i; j < INVENTORY_SIZE && inventory[j].slotSize == 0; j++) {
                remainingFree++;
            }
            if (remainingFree < bestGap) {
                bestGap = remainingFree;
                bestStart = i;
            }
        }
    }
    
    if (bestStart != -1) {
        return bestStart;
    }
    
    // Second pass is simple first fit
    for (int i = 0; i <= INVENTORY_SIZE - slotSize; i++) {
        bool isFree = true;
        for (int j = 0; j < slotSize; j++) {
            if (inventory[i + j].slotSize != 0) {
                isFree = false;
                break;
            }
        }
        if (isFree) {
            return i;
        }
    }
    
    return -1;
}

/* Swap out weapons to long term storage to make room for new weapon */
static int swapOutWeapons(Entity* entity, int neededSlots) {
    int slotsFreed = 0;
    int weaponsSwapped = 0;
    
    printf("SWAP OUT: Need %d slots, currently have %d free\n", 
           neededSlots, INVENTORY_SIZE - entity->inventoryUsedSlots);
    
    // Scan from the end swap out largest or non-artifact weapons first
    for (int i = INVENTORY_SIZE - 1; i >= 0 && slotsFreed < neededSlots; i--) {
        if (entity->inventory[i].slotSize == 0) continue;
        
        // Check if this is the start of a weapon
        bool isStart = (i == 0) ||
                       (entity->inventory[i-1].slotSize == 0) ||
                       (strcmp(entity->inventory[i-1].name, entity->inventory[i].name) != 0);
        
        if (!isStart) continue;
        
        // Never swap out artifact weapons
        if (entity->inventory[i].isArtifact) {
            printf("  Skipping artifact: %s\n", entity->inventory[i].name);
            continue;
        }
        
        // Move to long term storage if there's space
        if (entity->longTermCount < LONG_TERM_STORAGE) {
            Weapon w = entity->inventory[i];
            entity->longTermStorage[entity->longTermCount++] = w;
            slotsFreed += w.slotSize;
            weaponsSwapped++;
            
            printf("  Swapped out: %s (size %d) -> Long-term storage\n", w.name, w.slotSize);
            
            // Clear the weapon from inventory
            for (int j = i; j < i + w.slotSize && j < INVENTORY_SIZE; j++) {
                memset(&entity->inventory[j], 0, sizeof(Weapon));
            }
        }
    }
    
    entity->inventoryUsedSlots -= slotsFreed;
    if (entity->inventoryUsedSlots < 0) entity->inventoryUsedSlots = 0;
    
    printf("SWAP OUT Result: Freed %d slots, %d weapons moved to storage\n", slotsFreed, weaponsSwapped);
    
    return slotsFreed >= neededSlots ? 1 : 0;
}

/* Pick up weapon and add to inventory using contiguous allocation */
static int pickupWeapon(Entity* entity, const Weapon* weapon) {
    int totalAfterAdd = entity->inventoryUsedSlots + weapon->slotSize;
    
    if (totalAfterAdd > INVENTORY_SIZE) {
        return 0;
    }
    
    // Check for artifact combination overflow as cannot hold all 3 artifacts
    int solarCount = entity->hasSolarCore ? 1 : 0;
    int lunarCount = entity->hasLunarBlade ? 1 : 0;
    int eclipseCount = entity->hasEclipseRelic ? 1 : 0;
    
    if (weapon->isArtifact) {
        if (strcmp(weapon->name, "Solar Core") == 0) solarCount++;
        if (strcmp(weapon->name, "Lunar Blade") == 0) lunarCount++;
        if (strcmp(weapon->name, "Eclipse Relic") == 0) eclipseCount++;
    }
    
    // Cannot hold both Solar Core AND Lunar Blade with Eclipse Relic
    if (solarCount >= 1 && lunarCount >= 1 && eclipseCount >= 1) {
        return 0;
    }
    
    // Try to find contiguous free space
    int start = findFreeSpace(entity->inventory, weapon->slotSize);
    
    if (start == -1) {
        // First, try compaction
        compactInventory(entity->inventory, &entity->inventoryUsedSlots);
        start = findFreeSpace(entity->inventory, weapon->slotSize);
        
        if (start == -1) {
            // Still no space  try swapping out weapons
            printf("\n=== SWAP OUT NEEDED for %s (size %d) ===\n", weapon->name, weapon->slotSize);
            printf("Current used slots: %d/%d\n", entity->inventoryUsedSlots, INVENTORY_SIZE);
            
            if (!swapOutWeapons(entity, weapon->slotSize)) {
                printf("SWAP OUT FAILED: Not enough space even after swapping\n");
                return 0;
            }
            
            // After swap out, need to compact again
            compactInventory(entity->inventory, &entity->inventoryUsedSlots);
            start = findFreeSpace(entity->inventory, weapon->slotSize);
            
            if (start == -1) {
                printf("SWAP OUT FAILED: Still no contiguous space after swap\n");
                return 0;
            }
            
            printf("SWAP OUT SUCCESS: Now have %d/%d slots used\n", 
                   entity->inventoryUsedSlots, INVENTORY_SIZE);
        }
    }
    
    // Place weapon contiguously
    for (int i = start; i < start + weapon->slotSize && i < INVENTORY_SIZE; i++) {
        entity->inventory[i] = *weapon;
    }
    entity->inventoryUsedSlots += weapon->slotSize;
    
    return 1;
}

/* Swap in weapon from long term storage */
static int swapInWeapon(Entity* player, int storageIndex) {
    if (storageIndex < 0 || storageIndex >= player->longTermCount) return 0;
    
    Weapon weapon = player->longTermStorage[storageIndex];
    
    for (int i = storageIndex; i < player->longTermCount - 1; i++) {
        player->longTermStorage[i] = player->longTermStorage[i+1];
    }
    player->longTermCount--;
    
    return pickupWeapon(player, &weapon);
}

/* Records allocation and updates fragmentation count */
static int pickupWeaponTracked(Entity* entity, const Weapon* weapon, GameState* state) {
    int slotBefore = entity->inventoryUsedSlots;
    
    int result = pickupWeapon(entity, weapon);
    
    if (result && state) {
        // Find the start slot by scanning for the newly placed weapon
        int startSlot = -1;
        for (int i = 0; i < INVENTORY_SIZE; i++) {
            if (entity->inventory[i].id == weapon->id &&
                strcmp(entity->inventory[i].name, weapon->name) == 0) {
                if (i == 0 || entity->inventory[i-1].slotSize == 0 ||
                    strcmp(entity->inventory[i-1].name, weapon->name) != 0) {
                    startSlot = i;
                    break;
                }
            }
        }
        if (startSlot >= 0) {
            recordAllocation(state, startSlot, weapon->slotSize, weapon);
        }
        state->totalFragments = calculateFragmentation(entity->inventory);
    }
    
    return result;
}

/* Tracked version of swap in */
static int swapInWeaponTracked(Entity* player, int storageIndex, GameState* state) {
    if (storageIndex < 0 || storageIndex >= player->longTermCount) return 0;
    
    Weapon weapon = player->longTermStorage[storageIndex];
    
    for (int i = storageIndex; i < player->longTermCount - 1; i++) {
        player->longTermStorage[i] = player->longTermStorage[i+1];
    }
    player->longTermCount--;
    
    return pickupWeaponTracked(player, &weapon, state);
}

/* Get random weapon drop non-artifact weapons only */
static Weapon getRandomWeaponDrop() {
    int idx = 2 + (rand() % 6);
    return WEAPON_DB[idx];
}

/* Get artifact drop Solar Core or Lunar Blade */
static Weapon getArtifactDrop(int which) {
    return WEAPON_DB[which & 1];
}

/* Check if player has ultimate ability (both Solar Core AND Lunar Blade) */
static int hasUltimateAbility(Entity* player) {
    return (player->hasSolarCore && player->hasLunarBlade);
}

#endif
