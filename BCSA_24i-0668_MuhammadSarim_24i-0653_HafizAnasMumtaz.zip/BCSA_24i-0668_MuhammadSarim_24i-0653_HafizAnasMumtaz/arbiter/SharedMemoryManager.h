#ifndef SHARED_MEMORY_MANAGER_H
#define SHARED_MEMORY_MANAGER_H

#include <iostream>
#include <cstring>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include "GameState.h"

#define CHRONO_RIFT_SHM_KEY ((key_t)0x43524946)

/* SharedMemoryManager Manages SysV shared memory for IPC between Arbiter, HIP, and ASP */
class SharedMemoryManager {
private:
    int shmid;
    GameState* state;
    int isCreator;
    
public:
    /* Constructor creates or attaches to shared memory segment */
    SharedMemoryManager(const char* /*name*/, int create = 0) {
        isCreator = create;
        
        if (create) {
            // Remove any stale segment first, then create fresh
            int old = shmget(CHRONO_RIFT_SHM_KEY, sizeof(GameState), 0666);
            if (old != -1) 
              shmctl(old, IPC_RMID, NULL);

            shmid = shmget(CHRONO_RIFT_SHM_KEY, sizeof(GameState),
                           IPC_CREAT | IPC_EXCL | 0666);
            if (shmid == -1) throw "shmget create failed";
        } else {
            // Attach to existing segment (retry a few times in case arbiter is still starting)
            int retries = 10;
            shmid = -1;
            while (retries-- > 0) {
                shmid = shmget(CHRONO_RIFT_SHM_KEY, sizeof(GameState), 0666);
                if (shmid != -1) break;
                usleep(200000);
            }
            if (shmid == -1) throw "shmget open failed";
        }
        
        state = (GameState*)shmat(shmid, NULL, 0);
        if (state == (GameState*)-1) throw "shmat failed";
        
        if (create) initSynchronization();
    }
    
    /* Destructor  detaches and removes shared memory if creator */
    ~SharedMemoryManager() {
        if (state && state != (GameState*)-1) {
            shmdt(state);
            state = nullptr;
        }
        if (isCreator && shmid != -1) {
            shmctl(shmid, IPC_RMID, NULL);
            shmid = -1;
        }
    }
    
    /* Initialize all process shared mutexes and semaphores */
    void initSynchronization() {
        pthread_mutexattr_t mutexAttr;
        pthread_mutexattr_init(&mutexAttr);
        pthread_mutexattr_setpshared(&mutexAttr, PTHREAD_PROCESS_SHARED);
        pthread_mutex_init(&state->stateMutex, &mutexAttr);
        pthread_mutex_init(&state->actionMutex, &mutexAttr);
        pthread_mutex_init(&state->logMutex, &mutexAttr);
        pthread_mutex_init(&state->inputBuf.mutex, &mutexAttr);
        pthread_mutex_init(&state->inputBuf2.mutex, &mutexAttr);
        pthread_mutexattr_destroy(&mutexAttr);

        sem_init(&state->arbiterSemaphore, 1, 0);
        sem_init(&state->hipActionSem, 1, 0);
        sem_init(&state->aspActionSem, 1, 0);
        sem_init(&state->globalTurnSem, 1, 1);
        sem_init(&state->inputBuf.dataReady, 1, 0);
        sem_init(&state->inputBuf2.dataReady, 1, 0);

        state->inputBuf.head = 0;
        state->inputBuf.tail = 0;
        state->inputBuf2.head = 0;
        state->inputBuf2.tail = 0;

        state->actionLogHead = 0;
        state->actionLogCount = 0;
        state->hasWeaponDrop = 0;
        state->currentDrop.isAvailable = 0;
        state->currentDrop.pickedUp = 0;
        
        state->allocationCount = 0;
        state->totalFragments = 0;
        state->compactionCount = 0;
        memset(state->allocations, 0, sizeof(state->allocations));
        
        for (int i = 0; i < MAX_ACTION_LOG; i++)
            state->actionLog[i].message[0] = '\0';
    }
    
    /* Accessor methods */
    GameState* getState() { return state; }
    void lockState()   { pthread_mutex_lock(&state->stateMutex);   }
    void unlockState() { pthread_mutex_unlock(&state->stateMutex); }
    void lockAction()  { pthread_mutex_lock(&state->actionMutex);  }
    void unlockAction(){ pthread_mutex_unlock(&state->actionMutex);}
    void lockLog()     { pthread_mutex_lock(&state->logMutex);     }
    void unlockLog()   { pthread_mutex_unlock(&state->logMutex);   }
    
    /* Add entry to action log (circular buffer) */
    void addToActionLog(const char* message) {
        lockLog();
        int index = (state->actionLogHead + state->actionLogCount) % MAX_ACTION_LOG;
        snprintf(state->actionLog[index].message, 256, "%s", message);
        state->actionLog[index].timestamp = time(0);
        if (state->actionLogCount < MAX_ACTION_LOG) {
            state->actionLogCount++;
        } else {
            state->actionLogHead = (state->actionLogHead + 1) % MAX_ACTION_LOG;
        }
        unlockLog();
    }

    /* Push input to HIP1's buffer */
    void pushInput(const char* token) {
        pthread_mutex_lock(&state->inputBuf.mutex);
        int next = (state->inputBuf.tail + 1) % INPUT_BUF_SIZE;
        if (next != state->inputBuf.head) {
            strncpy(state->inputBuf.tokens[state->inputBuf.tail], token, 15);
            state->inputBuf.tokens[state->inputBuf.tail][15] = '\0';
            state->inputBuf.tail = next;
        }
        pthread_mutex_unlock(&state->inputBuf.mutex);
        sem_post(&state->inputBuf.dataReady);
    }

    /* Push input to HIP2's buffer (multiplayer) */
    void pushInput2(const char* token) {
        pthread_mutex_lock(&state->inputBuf2.mutex);
        int next = (state->inputBuf2.tail + 1) % INPUT_BUF_SIZE;
        if (next != state->inputBuf2.head) {
            strncpy(state->inputBuf2.tokens[state->inputBuf2.tail], token, 15);
            state->inputBuf2.tokens[state->inputBuf2.tail][15] = '\0';
            state->inputBuf2.tail = next;
        }
        pthread_mutex_unlock(&state->inputBuf2.mutex);
        sem_post(&state->inputBuf2.dataReady);
    }

    /* Pop input from HIP1's buffer */
    bool popInput(char* outToken, int outLen) {
        while (true) {
            struct timespec ts;
            clock_gettime(CLOCK_REALTIME, &ts);
            ts.tv_sec += 1;
            int rc = sem_timedwait(&state->inputBuf.dataReady, &ts);
            if (rc == -1) {
                if (!state->gameRunning) return false;
                continue;
            }
            pthread_mutex_lock(&state->inputBuf.mutex);
            if (state->inputBuf.head != state->inputBuf.tail) {
                strncpy(outToken, state->inputBuf.tokens[state->inputBuf.head], outLen - 1);
                outToken[outLen - 1] = '\0';
                state->inputBuf.head = (state->inputBuf.head + 1) % INPUT_BUF_SIZE;
                pthread_mutex_unlock(&state->inputBuf.mutex);
                return true;
            }
            pthread_mutex_unlock(&state->inputBuf.mutex);
        }
    }

    /* Pop input from HIP2's buffer (multiplayer) */
    bool popInput2(char* outToken, int outLen) {
        while (true) {
            struct timespec ts;
            clock_gettime(CLOCK_REALTIME, &ts);
            ts.tv_sec += 1;
            int rc = sem_timedwait(&state->inputBuf2.dataReady, &ts);
            if (rc == -1) {
                if (!state->gameRunning) return false;
                continue;
            }
            pthread_mutex_lock(&state->inputBuf2.mutex);
            if (state->inputBuf2.head != state->inputBuf2.tail) {
                strncpy(outToken, state->inputBuf2.tokens[state->inputBuf2.head], outLen - 1);
                outToken[outLen - 1] = '\0';
                state->inputBuf2.head = (state->inputBuf2.head + 1) % INPUT_BUF_SIZE;
                pthread_mutex_unlock(&state->inputBuf2.mutex);
                return true;
            }
            pthread_mutex_unlock(&state->inputBuf2.mutex);
        }
    }
};

#endif
