#!/bin/bash
# Chrono Rift - Launch Script
# Run this inside the Docker container after: make clean && make

pkill -f "./arbiters" 2>/dev/null
pkill -f "./hips" 2>/dev/null
pkill -f "./asps" 2>/dev/null

# Clean up any leftover shared memory from previous runs
rm -f /dev/shm/chrono_rift_shm 2>/dev/null
sleep 0.5

# Arbiter runs in foreground (handles spawning hip and asp itself)
./arbiters

echo "All processes stopped."
