/*
 It Controls enemy AI as each enemy has its own thread, waits for turn,
 then randomly attacks or skips. Handles wave respawning.
*/

#include <iostream>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fcntl.h>


#include "SharedMemoryManager.h"
#include <sys/shm.h>

//GLOBAL VARIABLES
SharedMemoryManager* g_shmManager = nullptr;
GameState* g_state = nullptr;
int g_running = 1;
static pthread_mutex_t g_runMutex = PTHREAD_MUTEX_INITIALIZER;

static int getRunning()       { pthread_mutex_lock(&g_runMutex); int v = g_running; pthread_mutex_unlock(&g_runMutex); return v; }
static void setRunning(int v) { pthread_mutex_lock(&g_runMutex); g_running = v;     pthread_mutex_unlock(&g_runMutex); }

struct EnemyThreadData
{
    pthread_t thread;
    int enemyId;
    int shouldExit;  
};

EnemyThreadData* g_enemyThreads = nullptr;
int g_numEnemies = 0;
static pthread_mutex_t g_waveMutex = PTHREAD_MUTEX_INITIALIZER;


// Safe logging
static void safe_log(const char* msg) {
    write(STDOUT_FILENO, msg, strlen(msg));
}


// SIGNAL HANDLER  SIGUSR1 for ultimate pause and SIGTERM for shutdown

static void signalHandler(int sig) {
    if (sig == SIGTERM) {
        safe_log("[ASP] Terminating\n");
        setRunning(0);
        if (g_state) {
            sem_post(&g_state->aspActionSem);
        }
    } else if (sig == SIGUSR1) {
        safe_log("[ASP] PAUSED by Ultimate!\n");
        raise(SIGSTOP);   // Suspend all enemy threads for 10 seconds
        safe_log("[ASP] RESUMED!\n");
    }
}

/* Get list of alive players for enemy targeting */
static int getAlivePlayers(int* out, int maxSize) {
    int count = 0;
    for (int i = 0; i < g_state->numPlayers && count < maxSize; i++)
        if (g_state->players[i].isAlive) out[count++] = i;
    return count;
}


//Each enemy runs independently and waits for turn signal, then chooses attack or skip

static void* enemyThread(void* arg) {
    EnemyThreadData* data = (EnemyThreadData*)arg;
    int enemyId = data->enemyId;
    
    while (getRunning() && g_state->gameRunning && !data->shouldExit) {
        
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        ts.tv_sec += 1;
        sem_timedwait(&g_state->aspActionSem, &ts);
        
        if (!getRunning() || !g_state->gameRunning || data->shouldExit) 
          break;
        
        g_shmManager->lockState();
        if (enemyId >= g_state->numEnemies) 
        {
            g_shmManager->unlockState();
            break;
        }
        
        int isMyTurn = (g_state->currentTurnOwner == 1 && g_state->currentEntityId == enemyId && 
                        !g_state->pendingAction.isReady);
        int isAlive = g_state->enemies[enemyId].isAlive;
        int isStunned = g_state->enemies[enemyId].isStunned;
        int hasFullStam = (g_state->enemies[enemyId].currentStamina >= g_state->enemies[enemyId].maxStamina);
        
        g_shmManager->unlockState();
        
        if (!isAlive || isStunned) continue;
        
        //Enemy decides the action
        if (isMyTurn && hasFullStam) {
            g_shmManager->lockState();
            
            if (enemyId < g_state->numEnemies &&
                g_state->enemies[enemyId].isAlive &&
                !g_state->pendingAction.isReady &&
                g_state->currentTurnOwner == 1 &&
                g_state->currentEntityId == enemyId) {
                
                int playerIndices[MAX_PLAYERS];
                int np = getAlivePlayers(playerIndices, MAX_PLAYERS);
                
                bool doSkip = (rand() % 100 < 30);   // 30% chance to skip
                
                if (doSkip) {
                    g_shmManager->unlockState();
                    sem_wait(&g_state->globalTurnSem);
                    g_shmManager->lockAction();
                    g_state->pendingAction.entityId = enemyId;
                    g_state->pendingAction.entityType = 1;
                    g_state->pendingAction.actionType = ACTION_SKIP;
                    g_state->pendingAction.targetId = -1;
                    g_state->pendingAction.weaponIndex = -1;
                    g_state->pendingAction.isReady = 1;
                    g_shmManager->unlockAction();
                    sem_post(&g_state->arbiterSemaphore);
                } else if (np > 0) {
                    int targetId = playerIndices[rand() % np];
                    g_shmManager->unlockState();
                    sem_wait(&g_state->globalTurnSem);
                    g_shmManager->lockAction();
                    g_state->pendingAction.entityId = enemyId;
                    g_state->pendingAction.entityType = 1;
                    g_state->pendingAction.actionType = ACTION_ATTACK_STRIKE;
                    g_state->pendingAction.targetId = targetId;
                    g_state->pendingAction.weaponIndex = -1;
                    g_state->pendingAction.isReady = 1;
                    g_shmManager->unlockAction();
                    sem_post(&g_state->arbiterSemaphore);
                } else {
                    g_shmManager->unlockState();
                }
            } else {
                g_shmManager->unlockState();
            }
        }
    }
    return nullptr;
}

/* Create threads for all enemies in current wave */
static void spawnEnemyThreads(int count) {
    g_enemyThreads = new EnemyThreadData[count];
    g_numEnemies = count;
    
    for (int i = 0; i < count; i++) {
        g_enemyThreads[i].enemyId = i;
        g_enemyThreads[i].shouldExit = 0;
        pthread_create(&g_enemyThreads[i].thread, nullptr, enemyThread, &g_enemyThreads[i]);
    }
}

/* Wait for all enemy threads to exit */
static void joinAllEnemyThreads() {
    for (int i = 0; i < g_numEnemies; i++) {
        if (g_enemyThreads[i].thread) {
            g_enemyThreads[i].shouldExit = 1;
            pthread_join(g_enemyThreads[i].thread, nullptr);
        }
    }
}

/* Handle wave transition by killing old threads and spawning new ones */
static void handleNewWave(int newCount) {
    for (int i = 0; i < g_numEnemies; i++) {
        g_enemyThreads[i].shouldExit = 1;
    }
    sem_post(&g_state->aspActionSem);
    
    for (int i = 0; i < g_numEnemies; i++) {
        if (g_enemyThreads[i].thread) {
            pthread_join(g_enemyThreads[i].thread, nullptr);
        }
    }
    
    delete[] g_enemyThreads;
    g_enemyThreads = nullptr;
    g_numEnemies = 0;
    
    spawnEnemyThreads(newCount);
}

/* It detects when wave changes and respawns enemy threads */
static void* waveMonitorThread(void*) {
    int lastCount = -1;
    while (getRunning() && g_state->gameRunning) {
        g_shmManager->lockState();
        int current = g_state->numEnemies;
        int gameActive = g_state->gameRunning;
        g_shmManager->unlockState();
        if (!gameActive) 
          break;
        if (lastCount == -1) 
          lastCount = current;
        else if (current != lastCount && current > 0) {
            pthread_mutex_lock(&g_waveMutex);
            handleNewWave(current);
            pthread_mutex_unlock(&g_waveMutex);
            lastCount = current;
        }
        sleep(1);
    }
    return nullptr;
}


//Main 
int main() {

    // Redirect stderr to /dev/null 
    int nullfd = open("/dev/null", O_WRONLY);
    if (nullfd != -1) { 
      dup2(nullfd, STDERR_FILENO); close(nullfd); 
    }
    safe_log("ASP Process Starting...\n");
    
    /* Setup signal handlers */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = signalHandler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGTERM, &sa, nullptr);
    sigaction(SIGUSR1, &sa, nullptr);
    sigaction(SIGUSR2, &sa, nullptr);
    signal(SIGPIPE, SIG_IGN);
    
    sleep(2);
    
    /* Connect to shared memory (retry up to 10 times) */
    int connected = 0;
    for (int retry = 0; retry < 10 && !connected; retry++) {
        try {
            g_shmManager = new SharedMemoryManager(SHM_NAME, 0);
            connected = 1;
        } catch (const char*) { sleep(1); }
    }
    if (!connected) { 
        write(STDERR_FILENO, "ASP ERROR: Could not connect\n", 30); 
        return 1; 
    }
    g_state = g_shmManager->getState();
    srand(g_state->rollNumber);
    safe_log("ASP Connected to shared memory!\n");
    
    /* Get initial enemy count and spawn threads */
    g_shmManager->lockState();
    int initCount = g_state->numEnemies;
    g_shmManager->unlockState();
    
    pthread_mutex_lock(&g_waveMutex);
    spawnEnemyThreads(initCount);
    pthread_mutex_unlock(&g_waveMutex);
    
    pthread_t waveMonitor;
    pthread_create(&waveMonitor, nullptr, waveMonitorThread, nullptr);
    
    // Main loop keep ASP alive 
    while (getRunning() && g_state->gameRunning) {
        sleep(1);
    }
    
    // Cleanup signal all enemy threads to exit 
    setRunning(0);
    
    pthread_mutex_lock(&g_waveMutex);
    for (int i = 0; i < g_numEnemies; i++) {
        g_enemyThreads[i].shouldExit = 1;
    }
    pthread_mutex_unlock(&g_waveMutex);
    
    sem_post(&g_state->aspActionSem);
    
    pthread_join(waveMonitor, nullptr);
    
    pthread_mutex_lock(&g_waveMutex);
    joinAllEnemyThreads();
    delete[] g_enemyThreads;
    g_enemyThreads = nullptr;
    pthread_mutex_unlock(&g_waveMutex);
    
    // Detach shared memory 
    if (g_state && g_state != (GameState*)-1) {
        int ret = shmdt((void*)g_state);
        if (ret == 0) {
            write(STDOUT_FILENO, "[ASP] Shared memory detached\n", 29);
        } else {
            write(STDERR_FILENO, "[ASP] shmdt failed\n", 19);
        }
        g_state = nullptr;
    }
    
    delete g_shmManager;
    g_shmManager = nullptr;
    
    safe_log("ASP Exiting.\n");
    return 0;
}
